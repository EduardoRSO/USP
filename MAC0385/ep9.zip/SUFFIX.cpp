#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct SUFFIX{
	string T;
	int length;
	vector<int> SA;
	vector<int> LCP;
	vector<int> LLCP;
	vector<int> RLCP;

	SUFFIX(string text){
		T = text;
		length = T.length();
		SA = vector<int>(length, 0);
		LCP = vector<int>(length, 0);
		LLCP = vector<int>(length, 0);
		RLCP = vector<int>(length, 0);

		buildSA();
		buildLCP();
		buildLRLCP(0,length-1,0);
	}

	void buildSA(){
		for(int i = length-1; i >= 0;i--) 
			SA[length -i - 1] = i;

		for(int i = 0; i < length; i++){
			for(int j = 0; j < length-i-1; j++){
				string A = T.substr(SA[j], length);
				string B = T.substr(SA[j+1], length);
				if(A.compare(B) > 0)
					swap(SA[j], SA[j+1]);
			}
		}
	}

	void buildLCP(){
		LCP[0] = 0;
		for(int i = 0; i < length-1;i++){
			int count = 0;
			string A = T.substr(SA[i],length);
			string B = T.substr(SA[i+1],length);
			for(int j = 0; A[j] == B[j];j++)
				count++;
		LCP[i+1] = count;
		}
	}

	void buildLRLCP(int i, int j, int side){
		int value;
		if(i == j-1){
			value = LCP[j]; 
		}
		else{
			int M = (i+j)/2;
			buildLRLCP(i, M, 2);
			buildLRLCP(M, j, 1);
			value = min(RLCP[M],LLCP[M]);
		}	
		if(side == 1)
			RLCP[i] = value;
		if(side == 2)
			LLCP[j] = value;	
		
	}

	void Print(){
		cout << "SA\n[ ";
		for(auto elem : SA)
			cout << elem << " ";
		cout << "]" << endl;
	
		cout << "LCP\n[ ";
		for(auto elem : LCP)
			cout << elem << " ";
		cout << "]" << endl;
	
		cout << "LLCP\n[ ";
		for(auto elem : LLCP)
			cout << elem << " ";
		cout << "]" << endl;
	
		cout << "RLCP\n[ ";
		for(auto elem : RLCP)
			cout << elem << " ";
		cout << "]" << endl;
	}

	void visualSuffixArray(){
		int i = 0;
		cout << endl;
		for(auto elem : SA)
			cout << i++ <<": "<<elem<<" := "<< T.substr(elem,length)<<endl;
		cout << endl;
	}

	bool Search(string P){
		int Plength = P.length();
		int L = 0, l = 0, M = 0, R = length-1, r = 0;
		while(L + 1 < R){
			//cout << "L: "<<L<<" l: "<<l<<" M: "<<M<<" R: "<<R<<" r:"<<r<<endl;
			M = (L+R)/2;
			if(l == r){
				//compara P e M a partir de l+1
				int m = l;
				while(m < Plength && P[m] == T[SA[M]+m]) m++;
				if(m+1 == Plength and P[m+1] == T[SA[M]+m+1]){ 
					return true;
				}else if(P[m] > T[SA[M]+m]){
					L = M;
					l = m;
				}else{
					R = M;
					r = m;
				}
			}
			else if(l > r){
				if(l < LLCP[M]){
					L = M;
				}
				else if(l > LLCP[M]){
					R = M;
					r = LLCP[M];
				}
				else{
					//compara P e M a partir de l+1
					int m = l;
					while(m < Plength && P[m] == T[SA[M]+m]) m++;
					if(m+1 == Plength and P[m+1] == T[SA[M]+m+1]){ 
						return true;
					}else if(P[m] > T[SA[M]+m]){
						L = M;
						l = m;
					}else{
						R = M;
						r = m;
					}
				}
			}
			else{
				if(r < RLCP[M]){
					R = M;
				}
				else if(r > RLCP[M]){
					L = M;
					l = RLCP[M];
				}
				else{
					//compara P e M a partir de r+1
					int m = r;
					while(m < Plength && P[m] == T[SA[M]+m]) m++;
					if(m+1 == Plength and P[m+1] == T[SA[M]+m+1]){ 
						return true;
					}else if(P[m] > T[SA[M]+m]){
						L = M;
						l = m;
					}else{
						R = M;
						r = m;
					}
				}
			}
		}
		//cout << "L: "<<L<<" l: "<<l<<" M: "<<M<<" R: "<<R<<" r:"<<r<<endl;
		if(length-SA[R]-1==Plength and P[Plength-1]==T[SA[R]+Plength-1]) return true;
		else if(length-SA[L]-1==Plength and P[Plength-1]==T[SA[L]+Plength-1]) return true;
		else return false;
	}


	int predecessor(string P){
		int L = 0, l = 0, r= 0, R = T.length()-1, M = 0;
		while(r < P.length() and P[r] == T[SA[R]+r]){ 
			r++;	
		}
		if(r+1 == P.length() and P[r] > T[SA[R]+r]) return R;
		while(L < R - 1){
			M = (L + R)/2;
			//cout << "L: " << L <<" l: " <<l<<" M: "<<M<<" R: "<<R<<" r: "<<r<<endl;
			if(l == r){
			    int m = l;
				while(m+1 != P.length() and P[m] == T[SA[M]+m]){ 
					m++;
				}
				if(P[m] > T[SA[M]+m]){
				    L = M;
				    l = m;
				}else{
				    R = M;
				    r = m;
				    
				}
			}
			else if(l > r){
				if(l < LLCP[M]){
					L = M;
				}
				else if (l > LLCP[M]){
					R = M;
					r = LLCP[M];
				}else{
					int m = l;
					while(m+1 != P.length() and P[m] == T[SA[M]+m]){ 
						m++;
					}
					if(P[m] > T[SA[M]+m]){
					    L = M;
					    l = m;
					}else{
					    R = M;
					    r = m;
					    
					}
				}
			}else {
				if(r < RLCP[M]){
					R = M;
				}else if(r > RLCP[M]){
					L = M;
					l = RLCP[M];
				}else{
			    		int m = r;
					while(m+1 != P.length() and P[m] == T[SA[M]+m]){ 
						m++;
					}
					if(P[m] > T[SA[M]+m]){
					    L = M;
					    l = m;
					}else{
					    R = M;
					    r = m;
					    
					}
			}
			}
		}
		//cout << "L: " << L <<" l: " <<l<<" M: "<<M<<" R: "<<R<<" r: "<<r<<endl;
		return L; 
	
	}

	int sucessor(string P){
		int L = 0, l = 0, r= 0, R = T.length()-1, M = 0;
		while(r+1 != P.length() and P[r] == T[SA[R]+r]){ 
			r++;	
		}
		if(r+1 == P.length() and r >= 1){
			if(r+1 > LCP[R])  return -1; 
			if(r+1 <= LCP[R]) return R;
		}
		while(L < R - 1){
			M = (L + R)/2;
		//	cout << "L: " << L <<" l: " <<l<<" M: "<<M<<" R: "<<R<<" r: "<<r<<endl;
			if(l == r){
			    	int m = l;
				while(m+1 != P.length() and P[m] == T[SA[M]+m]){ 
					m++;
				}
				if(P[m] >= T[SA[M]+m]){
				    L = M;
				    l = m;
				}else{
				    R = M;
				    r = m;
				    
				}
			}
			else if(l > r){
				if(l < LLCP[M]){
					L = M;
				}
				else if (l > LLCP[M]){
					R = M;
					r = LLCP[M];
				}else{
					int m = l;
					while(m+1 != P.length() and P[m] == T[SA[M]+m]){ 
						m++;
					}
					if(P[m] >= T[SA[M]+m]){
					    L = M;
					    l = m;
					}else{
					    R = M;
					    r = m;
					    
					}
				}
			}else {
				cout << r << " e " <<RLCP[M] << endl;
				if(r < RLCP[M]){
					R = M;
				}else if(r > RLCP[M]){
					L = M;
					l = RLCP[M];
				}else{
			    		int m = r;
					while(m+1 != P.length() and P[m] == T[SA[M]+m]){ 
						m++;
					}
					if(P[m] >= T[SA[M]+m]){
					    L = M;
					    l = m;
					}else{
					    R = M;
					    m = m;
					    
					}
			}
			}
		}
		//cout << "L: " << L <<" l: " <<l<<" M: "<<M<<" R: "<<R<<" r: "<<r<<endl;
		if(LCP[R] != 0) return R;
		return L; 
	
	}

	int NOcurrences(string P){
		return sucessor(P) - predecessor(P);
	}

	void Ocurrences(string P){
		int i = predecessor(P);
		int j = sucessor(P);
		cout <<"{\n";
		for(int k = 1; k <= j - i; k++)
		  cout<<" ["<<i+k<<"]: "<<SA[i+k]<<" = "<<T.substr(SA[i+k],length)<<endl;
		cout <<"}\n";
	}
};

int main(){
	SUFFIX *sf;
	string input;
	getline(cin,input);
	input.append("$");
	sf = new SUFFIX(input);
	sf->Print();
	sf->visualSuffixArray();
	while(input != 	"0"){
	cin >> input;
	cout <<"Search: "<< sf->Search(input) << endl;
	cout <<"NOcurrences "<<sf->NOcurrences(input) << endl;
	cout<<"Ocurrences "; sf->Ocurrences(input);
	}
	delete sf;
	return 0;
}
