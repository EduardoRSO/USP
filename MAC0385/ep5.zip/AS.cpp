#include <iostream>
#include "AS.h"

using namespace std;

int compare (const void * a, const void * b){
  return ( *(int*)a - *(int*)b );
}

AS::AS(Interval *arr[], int N){
	int vet[2*N] = {};
	int j = 0;
	list = NULL;
	//coloca todos os extremos dos intervalos em um vetor
       	for(int i=0;i<2*N;i+=2){
		list = insert(list,arr[j]);
		vet[i] = arr[j]->low;
		vet[i+1] = arr[j]->high;
		j++;
	}
	//ordeno o vetor
	qsort(vet, 2*N, sizeof(int), compare);

	//retiro as repetições do vetor de inteiros
	j = 1;
	for(int i=1; i < 2*N;i++){
		if(vet[i] != vet[i-1]){
			vet[j] = vet[i];
			j++;
		}
	}
	intervalCount = N; 
	root = createTree(vet, j, arr, N);
	
	//for(int i=0;i<2*N;i++) delete arr[i];
	//delete arr;
}

void AS::Segment(int x){
	Segments(root, x);
}

void AS::Print(){
	print(root);
}

IntervalList* AS::listaIntervalos(){
	return list;
}

int AS::contaIntervalos(){
	return intervalCount;
}
