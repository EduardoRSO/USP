#include <iostream>
#include "Node.h"

using namespace std;

Node* newNode(int n1, int n2, bool l, bool r){
	Node* node = new Node(); 
	node->maxLeft = n2;
	node->segm = new IntervalList(new Interval(n1,n2, l, r), NULL);
	node->left = NULL;
	node->right = NULL;
	return node;
}

//printa um intervalo unico
void printaIntervalo(Interval *temp){
	if(temp != NULL){
		if(temp->left) cout << "[";
		else cout << "(";
		cout << temp->low << ", " << temp->high;
		if(temp->right) cout << "]";
		else cout << ")";
	}
}

//printa os intervalos de uma lista de intervalos
void printaIntervalos(IntervalList *temp){
	if(!(temp == NULL)){
		printaIntervalo(temp->atual);
		if(temp->next != NULL) cout << ", ";
		else cout << ".";
		printaIntervalos(temp->next);
	}
}

//printa a arvore em duas dimensões 0 e 2
void print(Node* root, int space, int height){
	if(root == NULL) return;
	space += height;
	print(root->right, space);
	for(int i = height; i < space; i++){
		cout << ' ';		
	}
	cout << "maxLeft: " << root->maxLeft << " e ";
	printaIntervalos(root->segm);

	cout << endl;
	print(root->left, space);

}

//insere no fim da lista ligada de intervalos
IntervalList* insert(IntervalList *segm, Interval *i){
	if(segm == NULL) return new IntervalList(new Interval(i->low, i->high, i->left, i->right), NULL);
	else segm->next = insert(segm->next, i);
	return segm;
}


//remove o intervalo dado da lista de intervalos
IntervalList* remove(IntervalList *list, Interval *segm){
	if(list->atual == segm){
		IntervalList *temp = list->next;
		list->next = NULL;
		delete list;
		return temp;
	}else list->next = remove(list->next, segm);
	return list;
}

//retorna o valor maximo da sub arvore esquerda
int getMax(Node *node){
	if(node->right == NULL) return node->maxLeft;
	else return getMax(node->right);
}

//unifica dois nós colocando a uniao dos conjuntos, concatena os intervalos em comum e deleta
Node *unifica(Node *one, Node* two){
	int low = one->segm->atual->low;
	int high = two->segm->atual->high;
	bool right = false;
	bool left = false;
	if(one->segm->atual->left)  left = true;
	if(two->segm->atual->right) right = true;
	Node *node = newNode(low, high, left, right);
	node->left = one;
	node->right = two;
	node->maxLeft = getMax(node->left);	
	IntervalList *temp = one->segm;
	bool removeu = false;
	while(temp != NULL){
		IntervalList *itera = two->segm;
		IntervalList *prox_one = temp->next;
		removeu = false;
		while(itera != NULL){
			IntervalList *prox_two = itera->next;
			if(temp->atual->low == itera->atual->low and temp->atual->high == itera->atual->high){
			       	node->segm = insert(node->segm, temp->atual);
				one->segm = remove(one->segm, temp->atual);
				two->segm = remove(two->segm, itera->atual);
				break;
			}
			itera = prox_two;
		}
		temp = prox_one;
	}
	return node;
}

Node* createTree(int arr[], int arr_length, Interval *segmentos[], int N){
	vector<Node*> v;

	//criei todos os intervalos elementares
	v.push_back(newNode(LINF,arr[0], false, false));
	v.push_back(newNode(arr[0],arr[0], true, true));
	for(int i = 1; i < arr_length; i++){
		v.push_back(newNode(arr[i-1], arr[i], false, false));
		v.push_back(newNode(arr[i],arr[i], true, true));
	}
	v.push_back(newNode(arr[arr_length-1], HINF, false, false));

	//fiz cada nó apontar para os segmentos que estão contidos
	for(int i = 0; i < v.size(); i++){
		for(int j = 0; j < N; j++){
			if(segmentos[j]->low <= v.at(i)->segm->atual->low and segmentos[j]->high >= v.at(i)->segm->atual->high){
				v.at(i)->segm = insert(v.at(i)->segm, segmentos[j]);
			}
		}
	}

	//fiz com que o número de nós na fila seja uma potencia de dois	
	int tam = v.size();
	int closest = pow(2,floor(log2(tam)));
	int j = 2*closest - tam;
	for(int i = j; i < tam; i+=2){
		v[j] = unifica(v[i], v[i+1]);
		j++;
	}
	tam = j;

	while(true){
		j=0;
		if(tam == 1) break;
		else{
			for(int i = 0; i < tam; i+=2){
				v[j] = unifica(v[i],v[i+1]);
				j++;
			}
			tam = j;
		}
	}
	Node *root = v.at(0);
	return root;
}

//concatena duas listas de intervalos
IntervalList* Concat(IntervalList *i, IntervalList *b){
	IntervalList *itera = b;
	while(itera != NULL){
		i = insert(i, itera->atual);
		itera = itera->next;
	}
	return i;
}

//busca pelo segmento no qual x está contido
IntervalList* segments(Node *root, int x){
	IntervalList *i = NULL;
	if(root == NULL) return i;
	else if(x >= root->maxLeft){
	       	i = Concat(i, segments(root->right, x));
	}
	else if (x < root->maxLeft){
	       	i = Concat(i, segments(root->left, x));
	}
	if(x == root->maxLeft){ i = Concat(i, segments(root->left,x));}
	i = Concat(i, root->segm->next);
	return i;
}

//filtra repetições
IntervalList* filtra(IntervalList *i){
	for(IntervalList *atual = i; atual != NULL; atual = atual->next){
		Interval *one = atual->atual;
		for(IntervalList *prox = atual->next; prox != NULL; prox = prox->next){
			Interval *two = prox->atual;
			if(one->low == two->low and one->high == two->high){
				IntervalList *newProx = prox->next;
				prox->next = NULL;
				delete prox;
				atual->next = newProx;
				prox = atual;
			}
		}
	}
	return i;
}

//busca pelo segmento no qual x está contido
void Segments(Node *root, int x){
	IntervalList *i = segments(root, x);
	cout << x << ": ";
	if (i == NULL) cout << "Vazio" << endl;
	else{ 
		i = filtra(i);
		printaIntervalos(i);
	}
	delete i;
	return;
}

