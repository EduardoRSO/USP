#include <iostream>
#include "AS.h"
#include <math.h>

using namespace std;

class ASD{
	public:
		AS *atual;
		ASD *next;

		~ASD();
		ASD();
		void Segment(int x);
		void PrintASD();
};

ASD* Insert(ASD *asd, int x, int y);

