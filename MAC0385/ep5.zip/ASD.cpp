#include <iostream>
#include "ASD.h"

using namespace std;

ASD::~ASD(){
	delete atual;
	delete next;
}

ASD::ASD(){
	atual = NULL;
	next = NULL;
}

void printaPointerArray(Interval** arr,int i){
	for(int j = 0; j < i; j++) printaIntervalo(arr[j]);
}

//transforma uma lista de intervalos em um ponteiro de ponteiros de intervalo 
Interval** ListToPointerArray(IntervalList *list, int indice){
	Interval **arr = new Interval*[indice]; 
	IntervalList *temp = list; 
	for(int i = 0; i < indice; i++){
		Interval *atual = temp->atual;	
		arr[i] = new Interval(atual->low,atual->high,true,true);
		temp = temp->next;
	}
	return arr;
}

//Recebe dois inteiros e um ponteiro de asd. Retorna a asd dada acrescida de um item extra no inicio da lista ligada
ASD* ColocaNaFrente(ASD* asd, int x, int y){
	if(asd->atual == NULL){
		Interval *i = new Interval(x,y,true,true);
		asd->atual = new AS(&i,1);
		return asd;
	}else{

		ASD *newFirst = new ASD();
		Interval *i = new Interval(x,y,true,true);
		newFirst->atual = new AS(&i,1);
		newFirst->next = asd;
		return newFirst;
	} 
}

//Unifica dois nós seguidos se a soma dos seus segmentos é uma potencia de dois
ASD* UnificaPotencias(ASD* asd){
	if(asd != NULL){
		while(true){
			if(asd->next == NULL) break;
			int conta = asd->atual->intervalCount + asd->next->atual->intervalCount;
			if(log2(conta) == (int) log2(conta)){
				IntervalList *i = NULL;
				i = Concat(i, asd->atual->list);
				i = Concat(i, asd->next->atual->list);
				ASD *prox = asd->next->next;
				ASD* newFirst = new ASD();	
				Interval **arr = ListToPointerArray(i,conta);
				newFirst->atual = new AS(arr,conta);
				newFirst->next = prox;
				asd = newFirst;
			} else break;
		}
	}
	return asd;
}

ASD* Insert(ASD* asd, int x, int y){
	ASD* temp = ColocaNaFrente(asd,x,y);
	temp = UnificaPotencias(temp);
	return temp;
}

void ASD::Segment(int x){
	ASD *temp = this;
	cout << x << " está contido em: ";
	IntervalList *i = NULL;
	while(temp != NULL){
		i = Concat(i, segments(temp->atual->root, x));
		temp = temp->next;

	}
	if (i == NULL) cout << "Vazio";
	else{ 
		i = filtra(i);
		printaIntervalos(i);
	}
	cout << endl;
}

void ASD::PrintASD(){
	ASD *temp = this;
	while(temp != NULL){
		printaIntervalos(temp->atual->list);
		cout<< endl;
		temp->atual->Print();
		temp = temp->next;
	}
}
