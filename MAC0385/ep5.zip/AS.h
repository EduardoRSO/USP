#include <iostream>
#include "Node.h"

class AS{

	public:
		Node *root;
		IntervalList *list;
		int intervalCount;

		AS(Interval *arr[], int N);
		void Segment(int x);
		void Print();
		IntervalList* listaIntervalos();
		int contaIntervalos();
};
