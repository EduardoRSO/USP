#include <iostream>
#include <vector>
#include <math.h>
#include <climits>
#include <math.h>

#define LINF INT_MIN
#define HINF INT_MAX

using namespace std;

struct Interval{
	bool right;
	bool left;
	int low;
	int high;

	Interval(int n1, int n2, bool l, bool r){
		low = n1;
		high = n2;
		left = l;
		right = r;
	}
};

struct IntervalList{
	Interval *atual;
	IntervalList *next;

	IntervalList(Interval* ATUAL, IntervalList* NEXT){
		atual = ATUAL;
		next = NEXT;
	}

	~IntervalList(){
		delete atual;
		delete next;
	}
};

struct Node{
	int maxLeft;
	IntervalList *segm;
	Node *left;
	Node *right;

	~Node(){
		delete segm;
		delete left;
		delete right;
	}
};

Node* newNode(int n1, int n2, bool l, bool r);
void printaIntervalo(Interval *temp);
void print(Node* root, int space = 0, int height = 2);
IntervalList* insert(IntervalList *segm, Interval *i);
IntervalList* remove(IntervalList *list, Interval *segm);
int getMax(Node *node);
Node *unifica(Node *one, Node* two);
Node* createTree(int arr[], int arr_length, Interval *segmentos[], int N);
void printaIntervalos(IntervalList *temp);
IntervalList* Concat(IntervalList *i, IntervalList *b);
IntervalList* segments(Node *root, int x);
IntervalList* filtra(IntervalList *i);
void Segments(Node *root, int x);	



	
