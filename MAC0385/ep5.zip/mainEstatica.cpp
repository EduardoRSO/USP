#include <iostream>
#include "AS.h"

using namespace std;

int main(){

	cout<<"INSIRA A # DE SEGMENTOS SEGUIDO DOS INTERVALOS"<<endl;
	int pares, num1, num2;
	cin >> pares;
	Interval *arr[pares]; 
	for(int i=0;i < pares;i++){
		cin >> num1 >> num2;
		arr[i] = new Interval(num1,num2,true,true);
	}
	AS *tree = new AS(arr, pares);	
	cout << "INSIRA O VALOR DE X"<< endl;
	cout << "X == 0 quit"<< endl;
	while(true){	
	int x;
	cin >> x;
	//tree->Segment(x);
	if(x == 0) break;
	}
	tree->Print();
	cout << "Segmentos: ";
	printaIntervalos(tree->listaIntervalos());
	cout << "QTD de Segmentos: " << tree->contaIntervalos() <<endl;
	delete tree;
	for(int i=0; i< pares; i++) delete arr[i];
	return 0;
}
