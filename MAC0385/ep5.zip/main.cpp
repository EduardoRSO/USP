#include <iostream>
#include "ASD.h"
#include <vector>

using namespace std;

int main(){
	vector<ASD*> v;
	int op = -1;
	int indice;
	int valor;
	cout << "0 - Sair()\n1 - ASD()\n2 - Insert(r,[a,b])\n3 - Segment(r,x)\n4 - Print(r)" << endl;
	cout << "\n" << "Insira na seguinte ordem: ITEM ÍNDICE VALOR" << endl;
	while(op != 0 ){
		cin >> op >> indice >> valor;
		switch(op){
		
			case 0:
				for(ASD* asd: v) delete asd;
				v.clear();
				break;
			case 1: 
				v.push_back(new ASD());
				break;
			case 2:
				cout << "INSIRA [a,b]" << endl;
				int a, b;
				cin >> a >> b;
				v.at(indice) = Insert(v.at(indice), a, b);
				break;
			case 3:
				v.at(indice)->Segment(valor);
				break;
			case 4:
				v.at(indice)->PrintASD();
		}
	}
	return 0;
}
