#include <iostream>
#include <stdexcept>
#include <vector>
#include "SEQ.h"

using namespace std;

struct FRT{
	int N;
	vector<SEQ *> sequencias;
	vector<Node *> vertices;

	FRT(int x);
	~FRT();
	void deleteFromHash(int key);
	Node* value(int key);
	int key(int U, int V);
	void insert(int key, Node *value);

	bool connected(int U, int V);
	void link(int U, int V);
	SEQ* bringToFront(int x, SEQ *S);
	void cut(int U, int V);
	void Print();
};

FRT::~FRT(){
	for(auto elem : sequencias) delete elem;
}

void FRT::deleteFromHash(int key){
	delete vertices[key]->ptrseq;
}

Node* FRT::value(int key){
	return vertices[key];
}

int FRT::key(int U, int V){
	return U*N + V;
}

void FRT::insert(int key, Node *value){
	vertices[key] = value;
}

FRT::FRT(int x){
	N = x;
	sequencias = vector<SEQ *>(N, NULL);
	vertices = vector<Node *>(N*N, NULL);
	for(int i=0; i < N; i ++){
		sequencias[i] = EulerSequence(i, i);
		sequencias[i]->root->ptrseq = sequencias[i];
		sequencias[i]->index = i;
		insert(key(i,i), sequencias[i]->root);
	}
}

bool FRT::connected(int U, int V){
	return Find(value(key(U,U)))->ptrseq == Find(value(key(V,V)))->ptrseq;
}

void FRT::link(int U, int V){
	if(V < U) swap(U,V);

	Node *S = Find(value(key(U,U)));
	Node *R = Find(value(key(V,V)));

	SEQ *Ss = bringToFront(U,S->ptrseq);
	SEQ *Rs = bringToFront(V,R->ptrseq);

	sequencias[Rs->index] = NULL;

	auto UV = EulerSequence(U,V);
	auto VU = EulerSequence(V,U);
	auto UU = EulerSequence(U,U);

	insert(key(U,V), UV->root);
	insert(key(V,U), VU->root);
	insert(key(U,U), UU->root);


	Ss->Concat(*UV);
	Ss->Concat(*Rs);
	Ss->Concat(*VU);
	Ss->Concat(*UU);


	delete Rs;

	sequencias[Ss->index] = Ss;
	return;
}

SEQ* FRT::bringToFront(int x, SEQ *S1){
	auto temp = value(key(x, x));
	if (Find(temp)->ptrseq != S1) throw std::logic_error("GG");
	int k = S1->Order(temp);
	if(k == 0) return S1;
	SEQ* S2 = new SEQ();
	SEQ S3;
	S1->Slice(k-1, *S2);
	S1->Slice(0, S3);

	//deleteFromHash(key(S1->root->data[0], S1->root->data[1]));

	auto XX = EulerSequence(x,x);
	insert(key(x,x), XX->root);

	S3.Concat(*XX);
	S2->Concat(S3);

	S2->index = S1->index;

	// delete S1;
	return S2;
}

void FRT::cut(int U, int V){
	SEQ* S = Find(value(key(U,V)))->ptrseq;
	int k = S->Order(value(key(U,V)));
	int l = S->Order(value(key(V,U)));
	if(l < k){ swap(U,V); swap(k,l);}
	SEQ S2, *S3, S4, S5;
	S3 = new SEQ();
	S->Slice(k-1,S2);
	S2.Slice(0,*S3);
	int q = S3->Order(value(key(V,U)));
	S3->Slice(q-1,S4);
	S4.Slice(1,S5);
	S->Concat(S5);

	sequencias[S->index] = S;
	if(V < U) swap(U,V);
	sequencias[V] = S3;
	S3->index = V;

}

void FRT::Print(){
	for(auto elem: sequencias)
		if(elem != NULL){
			elem->root->inorder();
			cout << endl;
		}
}

int main(){
	FRT f(5);

	cout <<"-------"<<endl;
	f.Print();
	f.link(0,1);

	cout <<"-------"<<endl;
	f.Print();
	f.link(1,2);

	cout <<"-------"<<endl;
	f.Print();
	f.link(0,3);

	cout <<"-------"<<endl;
	f.Print();
	f.cut(0,1);

	cout <<"-------"<<endl;
	f.Print();

	return 0;
}
