#include <iostream>
#include <vector>

using namespace std;

struct SEQ;
//using splay tree

struct Node{
	
	int sz;
	int data[2];
	SEQ *ptrseq;
	
	Node *left, *right, *parent;

	Node(int u, int v);
	~Node();	
	int size();
	void recalc();	
	Node* rotateRight();
	Node* rotateLeft();
	Node* search(int key);
	void inorder();
};

struct SEQ{
	
	Node *root;
	int index;

	SEQ();
	~SEQ();
	Node* splay(Node *root, int key);
	Node* splay(Node *node);
	int Order(Node *x);
	void Slice(int k, SEQ &newSEQ);
	void Concat(SEQ &other);
	void Concat(int u, int v);
	void Print();
};

SEQ* EulerSequence(int u, int v);
Node* Find(Node *x);
