#include <iostream>
#include "SEQ.h"
#include <stdexcept>

void printaEstrutura(Node *root, int space =2, int height =2){
	if(root == NULL) return;

	space += height;

	printaEstrutura(root->right, space);
	cout << endl;

	for(int i = height; i < space; i++) cout << ' ';
	cout <<"[ "<<(char) (root->data[0]+'A')<<", "<< (char) (root->data[1]+'A')<<" ]"<< endl;

	cout << endl;
	printaEstrutura(root->left, space);
}

Node::Node(int a, int b){
	data[0] = a;
	data[1] = b;
	sz = 1;
	left = right = parent = NULL;
	recalc();
}

Node::~Node(){
	if(parent){
		if(parent->left == this) parent->left = NULL;
		else parent->right = NULL;
	}
	delete left;
	delete right;
}

int Node::size(){
	if(this == NULL) return 0;
	return sz;
}

void Node::recalc(){
	if(this == NULL) return;
	sz = left->size() + right->size() + 1;;
}

Node* Node::rotateRight(){
	Node *newCenter = left;
	Node *baby = newCenter->right;

	left = baby;
	newCenter->right = this;
	newCenter->parent = parent;
	newCenter->ptrseq = ptrseq;
	parent = newCenter;

	if(baby) baby->parent = this;

	recalc();
	newCenter->recalc();

	return newCenter;
}

Node* Node::rotateLeft(){
	Node *newCenter = right;
	Node *baby = newCenter->left;

	right = baby;
	newCenter->left = this;
	newCenter->parent = parent;
	newCenter->ptrseq = ptrseq;
	parent = newCenter;

	if(baby) baby->parent = this;

	recalc();
	newCenter->recalc();

	return newCenter;
}

//Devolve o nó de indice key
Node* Node::search(int key){
	if(key < left->size()) return left->search(key);
	if(key == left->size()) return this;
	return right->search(key - left->size() -1);
}

//Imprime a árvore
void Node::inorder(){
	if(this == NULL) return;
	left->inorder();
	cout <<(char) (data[0]+65) <<(char) (data[1]+65) << " ";
	right->inorder();
}

//Splay de baixo pra cima
Node* SEQ::splay(Node* node){
	while(node->parent != NULL){
		if(node->parent->left == node){
			if(node->parent->parent == NULL){
				node->parent->rotateRight();
			}else{
				if(node->parent->parent->left == node->parent){
					node->parent->parent->left = node->parent->rotateRight();
				}else{
					node->parent->parent->right = node->parent->rotateRight();
				}
			}
		}else{
			if(node->parent->parent == NULL){
				node->parent->rotateLeft();
			}else{
				if(node->parent->parent->left == node->parent){
					node->parent->parent->left = node->parent->rotateLeft();
				}else{
					node->parent->parent->right = node->parent->rotateLeft();
				}
			}


		}
	}
	return node;
}

//Splay de cima pra baixo
Node* SEQ::splay(Node *node, int key){
	if(key >= node->size()) throw logic_error("Vish man");
	if(node == NULL || key == node->left->size()) return node;
	if(node->left->size() > key){
		if(node->left->left->size() > key){
			node->left->left = splay(node->left->left, key);
			node = node->rotateRight();
		}else if(node->left->left->size() < key){
			node->left->right = splay(node->left->right, key - node->left->left->size() -1);
			node->left = node->left->rotateLeft();
		}
		node = node->rotateRight();
	}else{
		key = key - node->left->size() - 1;
		if(node->right->left->size() > key){
			node->right->left = splay(node->right->left, key);
			node->right = node->right->rotateRight();
		}
		else if(node->right->left->size() < key){
			node->right->right = splay(node->right->right, key -1 - node->right->left->size());
			node = node->rotateLeft();
		}
		node = node->rotateLeft();

	}
	return node;

}

SEQ::SEQ(){
	root = NULL;
	index = -1;
}

SEQ::~SEQ(){
	delete root;
}

//Retorna uma sequencia que tem apenas 1 nó
SEQ* EulerSequence(int u, int v){
	SEQ *S = new SEQ();
       	S->Concat(u,v);

	return S;
}

//Devolve a raiz do nó x
Node* Find(Node *x){
	Node *find = x;
	if(x == NULL) throw logic_error("Vish mano");
	while(x->parent){
		x = x->parent;
	}
	return x;
}

//Devolve o indice de X
int SEQ::Order(Node *x){
	root = splay(x);
	return root->left->size();

}

//Corta uma sequencia em duas
void SEQ::Slice(int key, SEQ &newSEQ){
	delete newSEQ.root;
	root = splay(root, key);
	newSEQ.root = NULL;
	newSEQ.root = root->right;
	newSEQ.root->parent = NULL;
	root->right = NULL;
	root->recalc();

}


//Unifica duas sequencias
void SEQ::Concat(SEQ &other){
	if(root != NULL){
		root = splay(root, root->size()-1);
		root->right = other.root;
		if(root->right) root->right->parent = root;
		root->recalc();
		other.root=NULL;
	}
	else{
		root = other.root;
		other.root = NULL;
	}
}

//Insere um par UV na sequencia
void SEQ::Concat(int u, int v){
	if(root != NULL){
		root = splay(root,root->size()-1);
		root->right = new Node(u,v);
		root->recalc();
	}else{
		root = new Node(u,v);
	}
}

//Imprime a sequência
void SEQ::Print(){
	root->inorder();
	cout << endl;
}

