#include <iostream>
#include "STACK.h"

STACK::STACK(){
	root = NULL;
}
void STACK::ADD_PUSH(int t, int value){
	root = insert(root, t, 1, value);
}
void STACK::ADD_POP(int t){
	int value = 0;
	root = insert(root, t, -1, value);
}
void STACK::REMOVE_PUSH(int t){
	root = remove(root, t);
}
void STACK::REMOVE_POP(int t){
	root = remove(root, t);
}
int STACK::SIZE(int t){
	return size(root, t);
}

int STACK::TOP(int t){
	return kth(root, t, 1).second;
}
int STACK::KTH(int t, int k){
	return kth(root, t, k).second;
}

void STACK::PRINT(){
	if(root == NULL) std::cout << "Empty!" << std::endl;
	std::cout << "\n";
	print("", root, false);
}

void STACK::PRINT(int t){
	if(root == NULL) std::cout << "Empty!" << std::endl;
	print(root, t);
	std::cout << "\n";
}
