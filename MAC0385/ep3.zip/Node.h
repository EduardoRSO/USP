#include <iostream>
#include <utility>

class Node{
        public:
                int key;
                int weight;
                int sum;
                int smax;
                int height;
                int value;
                Node *left;
                Node *right;
};
	
Node* newNode(int key, int weight, int value);
Node* rotateLeft(Node *x);
Node* rotateRight(Node *y);
Node* insert(Node* node, int key, int weight, int value);

Node* remove(Node* node, int key);
void atualizaAtribs(Node* node);
std::pair<int, int> par(int num1, int num2);
std::pair<int, int> kth(Node *node, int key, int k);
int getKthLeft(Node *node, int k);
int size(Node *node, int key);
void print(const std::string& prefix, const Node* node, bool isLeft);
void print(Node *node, int key);
