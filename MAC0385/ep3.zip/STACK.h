#include <iostream> 
#include "Node.h" 
  
class STACK{ 
 
        public: 
                Node *root; 
 
                STACK(); 
                void ADD_PUSH(int t, int value); 
                void ADD_POP(int t); 
                void REMOVE_PUSH(int t); 
                void REMOVE_POP(int t); 
                int TOP(int t);
	      	int SIZE(int t);	
                int KTH(int t, int k); 
                void PRINT();
	      	void PRINT(int t);	
}; 

