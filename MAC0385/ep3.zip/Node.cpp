#include "Node.h"

int max(int a,  int b){
	if(a>b) return a;
	return b;
}

int height(Node *node){
	if(node != NULL)
		return node->height;
	return 0;
}

int weight(Node *node){
	if(node != NULL)
		return node->weight;
	return 0;
}

int sum(Node *node){
	if(node != NULL)
		return node->sum;
	return 0;
}

int smax(Node *node){
	if(node != NULL)
		return node->smax;
	return 0;
}


Node* newNode(int key, int weight, int value){
	Node *node = new Node();
	node->key = key;
	node->weight = weight;
	node->smax = max(0, weight);
	node->sum = weight;
	node->value = value;
	node->height = 0;
	node->left = NULL;
	node->right = NULL;

	return node;
}

void atualizaAtribs(Node *node){
	node->height = max(height(node->left),height(node->right))+1;
	node->sum = sum(node->left) + sum(node->right) + node->weight;
	node->smax = max(smax(node->right), sum(node->right) + node->weight + smax(node->left));
}

Node *rotateRight(Node *y){
	Node *x = y->left;
	Node *T2 = x->right;

	x->right = y;
	y->left = T2;

	atualizaAtribs(y);
	atualizaAtribs(x);
	return x;
}

Node *rotateLeft(Node *x){
	Node *y = x->right;
	Node *T2 = y->left;

	y->left = x;
	x->right = T2;

	atualizaAtribs(x);
	atualizaAtribs(y);
	return y;
}


int balanceFactor(Node *node){
	if(node != NULL)
		return height(node->left) - height(node->right);
	return 0;
}

Node* balance(Node* node){
	if(balanceFactor(node) < -1){
		if(balanceFactor(node->right) > 0){
			node->right = rotateRight(node->right);
		}
		node = rotateLeft(node);
	}
	else if(balanceFactor(node) > 1){
		if(balanceFactor(node->left) < 0){
			node->left = rotateLeft(node->left);
		}	
		node = rotateRight(node);
	}
	return node;
}

Node* insert(Node* node, int key, int weight, int value){
	if(node == NULL) return newNode(key, weight, value);
	if(key < node->key) node->left = insert(node->left, key, weight, value);
	else if(key > node->key) node->right = insert(node->right, key, weight, value);

	atualizaAtribs(node);

	return balance(node);
}

Node* minValue(Node *node){
	Node *current = node;
	while (current->left != NULL){ current = current->left;}
	return current;
}


Node* remove(Node* node, int key){
	if(node == NULL) return NULL;
	if(key < node->key) node->left = remove(node->left, key);
	else if(key > node->key) node->right = remove(node->right, key);
	else{
		if(node->left == NULL or node->right == NULL){
			Node *temp;
			if(node->left == NULL) temp = node->right;
			else{temp = node->left;}
			node = temp;
		}
		else{
			Node *temp = minValue(node->right);
			node->key = temp->key;
			node->right = remove(node->right, temp->key);
		}
	}
	
	atualizaAtribs(node);
	return balance(node);
}

std::pair<int, int> par(int num1, int num2){
	return std::make_pair(num1, num2);
}

int getKthLeft(Node *node, int k){
	if(node->right != NULL and smax(node->right) >= k){
		return getKthLeft(node->right, k);
	}
	else{
		k = k - sum(node->right);
	}
	
	k = k - node->weight;
	if(k == 0) return node->value;
	else return getKthLeft(node->left, k);
}

// par(int a, int b) se a = 0 n achou, se a = 1 achou
std::pair<int, int> kth(Node *node, int key, int k){
	if(node == NULL) return par(-1,k); //null
	if(key < node->key){
		return kth(node->left, key, k); 
	}	
	else if(key > node->key){
		auto verifica = kth(node->right, key, k);
		if(verifica.first == 1) return verifica;
		k = verifica.second;
	}
	k = k - weight(node);
	if(k == 0) return par(1, node->value);
	if(node->left != NULL and k <= smax(node->left)){
		return par(1, getKthLeft(node->left, k));
	}
	else{
		k = k - sum(node->left);
		return par(0, k);
	}
}

int size(Node* node, int key){
	if(node == NULL) return 0;
	if(key < node->key) return size(node->left, key);
	int count = sum(node->left) + weight(node) + size(node->right, key);
	return count;
}

void print(const std::string& prefix, const Node *node, bool isLeft)
{
    if(node != NULL )
    {
        std::cout << prefix;
        std::cout << (isLeft ? "├──" : "└──" );
	std::cout << "["<<node->key<<", "<<node->weight<<", "<<node->smax<<", "<<node->value<<"]" << std::endl;
	print( prefix + (isLeft ? "│   " : "    "), node->left, true);
        print( prefix + (isLeft ? "│   " : "    "), node->right, false);
    }
}

void print(Node *node, int key){	
	int tam = size(node, key);
	std::cout << "[";
	for(int i = 1; i <= tam; i++)
		std::cout << " " << kth(node, key, i).second << " ";
	std::cout<< "]";
}
