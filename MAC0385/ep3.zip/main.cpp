#include <iostream>
#include "STACK.h"

using namespace std;

int main(){
	STACK v;
	int op=-1, d, x;
	int id = 0;
	cout <<"0 - Sair\n1 - STACK()\n2 - PUSH(t,x)\n3 - POP(t)\n4 - REMOVE_PUSH(t)\n5 - REMOVE_POP(t)\n6 - TOP(t)\n7 - SIZE(t)\n8- KTH(t, x)\n9 - PRINT(t)\n10 - PRINT()" << endl;
	cout << "\n" << "Insira na seguinte ordem: ITEM TEMPO VALOR" << endl;
	while(op != 0){
		cin >> op >> d >> x;
		switch(op){
			case 0: 
				break;
			case 1:
				v = STACK();	
				break;
			case 2:
				v.ADD_PUSH(d, x);
				break;
			case 3:
				v.ADD_POP(d);
				break;
			case 4:
				v.REMOVE_PUSH(d);
				break;
			case 5:
				v.REMOVE_POP(d);
				break;
			case 6:
				cout <<"TOP: " <<v.TOP(d) << endl;
				break;
			case 7:
				cout <<"SIZE: "<<v.SIZE(d) << endl;
				break;
			case 8:
				cout <<"KTH: "<< v.KTH(d,x) << endl;	
				break;
			case 9:
				v.PRINT(d);
				break;
			case 10:
				v.PRINT();
				break;
		}
	}
	return 0;
}
