#include <iostream>
#include "Node.h"

Node::Node(int x){
	value = x;
	left = NULL;
	right = NULL;
	count = 1;
}

Node::~Node(){
	if(right != NULL){
		right->count--;
		if(right->count == 0) delete right;
	}
	if(left != NULL){
		left->count--;
		if(left->count == 0) delete left;
	
	}
}

bool Node::search(int x){
	if(this == NULL) return false;
	else if(x > value) return right->search(x);
	else if(x < value) return left->search(x);
	else return true;
}

Node* Node::copia(){
	if(this == NULL) return NULL;
	Node *e = new Node(value);

	e->right = right;
	if(right != NULL) e->right->count++;
	
	e->left = left;
	if(left != NULL) e->left->count++;

	return e;
}

Node* Node::min(){
	if(this == NULL) return NULL;
	else if(left == NULL) return this;
	else return left->min();
}

Node* Node::insert(int x){
	if(this == NULL) return new Node(x);
	Node* novo = copia();
	if(x > value){
		if(novo->right != NULL) novo->right->count--;
		novo->right = right->insert(x);
	}else{
		if(novo->left != NULL) novo->left->count--;
		novo->left = left->insert(x);
	}
	return novo;
}

Node* Node::remove(int x){
	Node *novo = NULL;
	Node *temp = NULL;
	if(this == NULL) return NULL;
	else if(x < value){
		novo = this->copia();
		if(novo->left != NULL) novo->left->count--;
		novo->left = left->remove(x);
	}
	else if(x > value){
		novo = this->copia();
		if(novo->right != NULL) novo->right->count--;
		novo->right = right->remove(x);
	}
	else if(right != NULL && left != NULL){
		temp = right->min();
		novo = temp->copia();
		//if(novo->left != NULL) novo->left->count--;
		if(novo->right != NULL) novo->right->count--;
		novo->right = right->remove(temp->value);
		novo->left = left;
		
		//mudei aquo
		if(novo->left != NULL) novo->left->count++;

	}
	else{
		//temp = this;
		if(left == NULL){
			novo = right; //->copia();
			//novo = right->copia();
			
		}else{ //if(right == NULL){
			novo = left; //->copia();
			//novo= left->copia();
			
		}
		if(novo != NULL) novo->count++;
	}
	return novo;
}
