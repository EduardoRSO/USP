#include <iostream>
#include "Node.h"

class BST{
	private:
		friend void printBST(const std::string& prefix, const Node* node, bool isLeft);
	public:
		Node *root;

		BST();
		~BST();
		BST* Insert(int x);
		BST* Delete(int x);
		bool Search(int x);
		int Min();
		void Print();
};
