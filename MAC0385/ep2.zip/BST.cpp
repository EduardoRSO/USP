#include <iostream>
#include "BST.h"

BST::BST(){
	root = NULL;
}

BST::~BST(){
	if(root != NULL){
		root->count--;
		if(root->count == 0) delete root;
	}
}

BST* BST::Insert(int x){
	BST *e = new BST();
	if(this->Search(x)){
		std::cout << "ERROR: Value alredy inserted. Returned empty BST" << std::endl;
	}
	else{
		e->root = root->insert(x);
	}
	return e;	
}

BST* BST::Delete(int x){
	BST *e = new BST();
	e->root = root->remove(x);
	return e;
}

bool BST::Search(int x){
	return root->search(x);
}

int BST::Min(){
	Node *temp = root->min();
	if(temp == NULL) return -1;
	return temp->value;
}

void printBST(const std::string& prefix, const Node *node, bool isLeft)
{
    if(node != NULL )
    {
        std::cout << prefix;
        std::cout << (isLeft ? "├──" : "└──" );
        std::cout << node->value << std::endl;
        printBST( prefix + (isLeft ? "│   " : "    "), node->left, true);
        printBST( prefix + (isLeft ? "│   " : "    "), node->right, false);
    }
}

void BST::Print(){
	if (root == NULL) std::cout << "Empty BST!" << std::endl;
	else printBST("", root, false);	
}

