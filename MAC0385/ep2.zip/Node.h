#include <iostream>

class Node{

	public:
		int value;
		Node *left;
		Node *right;
		int count;
	
		Node(int x);
		~Node();
		Node* copia();
		Node* insert(int x);
		Node* remove(int x);
		Node* min();
		bool search(int x);
};
