#include <iostream>
#include <vector>
#include "BST.h"

using namespace std;

int main(){
	vector<BST*> v;
	int op=-1, d, x;
	int id = 0;
	cout <<"0 - Sair\n1 - BST(): cria e devolve uma BST vazia\n2 - Insert(r,x): insere x na BST com raiz r\n3 - Delete(r,x): remove x da BST com raiz r\n4 - Search(r,x): true se x está na BST com raiz r e false caso contrário\n5 - Min(r): menor chave presente na BST com raiz r\n6 - Print(r): imprime todos os elementos na BST com raiz r" << endl;
	cout << "\n" << "Insira na seguinte ordem: ITEM ÍNDICE VALOR" << endl;
	while(op != 0){
		cin >> op >> d >> x;
		switch(op){
			case 0: 
				for(BST* bst: v){
					//cout << id << endl;
					id++;
					delete bst;
				}
				v.clear();
				break;
			case 1:
				v.push_back(new BST());	
				break;
			case 2:
				v.push_back(v.at(d)->Insert(x));
				break;
			case 3:
				v.push_back(v.at(d)->Delete(x));
				break;
			case 4:
				cout << "Search: " <<v.at(d)->Search(x) << endl;
				break;
			case 5:
				cout << "Min: " << v.at(d)->Min()<< endl;;
				break;
			case 6:
				v.at(d)->Print();
				cout << "\n" << endl;
				break;
		}
	}
	return 0;
}
