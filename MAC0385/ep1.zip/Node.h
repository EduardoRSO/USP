#include <iostream>
#include <math.h>

class Node{
	public:
		Node* parent;
		Node* jump;
		int value;
		int depth;
		int count; //numero de variaveis apontando p/ esse nó. Usado no free.

		Node(int x, Node* p, int d);
		~Node();
		Node* LA(int k);
		friend Node* LCA(Node* u, Node* v);
};
