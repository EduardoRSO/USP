#include <iostream>
#include "DEQUE.h"

DEQUE::DEQUE(){
	first = last = NULL;
	length = 0;
}

DEQUE::~DEQUE(){
	if(first != NULL){
		first->count--;
		if(first->count == 0){
			 delete first;
		}
		last->count--;
		if(last->count == 0){
			delete last;
		}
	}
}

int DEQUE::Front(){
	if(length == 0) return -1;
	return first->value;
}

int DEQUE::Back(){
	if(length == 0) return -1;
	return last->value;
}

int DEQUE::Kth(int k){
	if(k > length){
		std::cout << "ERROR: k > deque->length" << std::endl;
		return -1;
	}
	if(first == NULL){
		return 0;	
	}
	Node* mid = LCA(first, last);
	int l1 = first->depth - mid->depth;
	int l2 =  last->depth - mid->depth;
	if(k -1 < l1){
		Node *tmp = first->LA(k-1);
		return tmp->value;	
	}
	else{
		Node *tmp = last->LA(l1+l2+1-k);
		return tmp->value;		
	}
}

DEQUE* DEQUE::PushFront(int x){
	DEQUE* e = new DEQUE();
	if(first == NULL){
		Node* u = new Node(x, NULL, 1);
		e->first = u;
		e->last = u;
		u->count = 2;
		e->length = 1;
	}
	else{
		e->first = new Node(x, first, first->depth+1);
		e->last = last;
		e->first->count = 1;
		e->first->parent->count++;
		e->first->jump->count++;//aqui e->first != e->first->jump
		e->last->count++;
		e->length = length+1;
	}
	return e;
}

DEQUE* DEQUE::Swap(DEQUE* d){
	DEQUE* e = new DEQUE();
	e->first = d->last;
	e->last  = d->first;
	e->length = d->length;
	
	if(d->first != NULL){
		e->first->count++;
		e->last->count++;
	}

	return e;
}

DEQUE* DEQUE::PushBack(int x){
	DEQUE* e = Swap(this);
	DEQUE* f = e->PushFront(x);
	DEQUE* g = Swap(f);
	delete e;
	delete f;
	return g;
}

DEQUE* DEQUE::PopFront(){
	if(first == NULL){
		std::cout << "ERROR: empty deque can not PopFront()" << std::endl;
		return NULL;	
	}
	else{
		DEQUE* e = new DEQUE();

		if(first == last){
			//devolve a deque e vazia
		}			
		else {
			if(first == LCA(first, last)){
				e->first = last->LA(last->depth - first->depth -1);
			}
			
			else{
				e->first = first->parent;
			}

			e->last  = last;
			e->length = length -1;
			e->first->count++;
			e->last->count++;
			
		}
		return e;
	}
}

DEQUE* DEQUE::PopBack(){
	DEQUE* e = Swap(this);
	DEQUE* f = e->PopFront();
	DEQUE* g = Swap(f);
	delete e;
	delete f;
	return g;
}

void DEQUE::Print(){
	if(first == NULL){
		std::cout << "Empty!\n";
		return;
	}
	Node* lca = LCA(first, last);
	int length = first->depth + last->depth - 2*lca->depth +1;
	
	int items[length];
	for(int i=0; i<length;i++) items[i] = -1;
	
	//1 ... lca
	for(Node* temp = first; temp != lca->parent; temp = temp->parent){
		items[first->depth - temp->depth] = temp->value;
	}
	
	//last .. lca-1
	for(Node* temp = last; temp != lca; temp = temp->parent){
		items[length - (last->depth - temp->depth) -1] = temp->value;
	}

	for(int i = 0; i < length; i++)
		std::cout << items[i] << " ";
	std::cout << std::endl;	

}



