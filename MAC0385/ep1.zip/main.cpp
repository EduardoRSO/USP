#include <iostream>
#include <vector>
#include "DEQUE.h"

using namespace std;

int main(){
	vector<DEQUE*> v;
	int op=-1, d, x;
	cout <<"0- Sair\n1- Deque(): cria e devolve uma deque vazia\n2- Front(d): devolve o elemento no extremo front de d\n3- Back(d): devolve o elemento no extremo back de d\n4- PushFront(d,x): insere x no extremo front de d\n5- PushBack(d,x): insere x no extremo back de d\n6- PopFront(d): remove o elemento no extremo front de d\n7- PopBack(d): remove o elemento no extremo back de d\n8- Kth(d,k): k-ésimo elemento de d, onde o front é o primeiro elemento de d\n9- Print(d): imprime todos os elementos da deque d" << endl;
	cout << "\n" << "Insira na seguinte ordem: ITEM ÍNDICE VALOR" << endl;
	while(op != 0){
		cin >> op >> d >> x;
		switch(op){
			case 0: 
				for(DEQUE* deque: v) delete deque;
				v.clear();
				break;
			case 1:
				v.push_back(new DEQUE());	
				break;
			case 2:
				if(d > v.size()){
				       	cout << "Erro" << endl;
				}
				else{
					cout << "Front: " << v.at(d)->Front() << endl;
				}
				break;
			case 3:
				if(d > v.size()) cout << "Erro" << endl;
				else{
					cout << "Back: " << v.at(d)->Back() << endl;
				}
				break;
			case 4:
				if(d > v.size()) cout << "Erro" << endl;
				else{
					v.push_back(v.at(d)->PushFront(x));
				}	
				break;
			case 5:
				if(d > v.size()) cout << "Erro" << endl;
				else{
					v.push_back(v.at(d)->PushBack(x));
				}	
				break;
			case 6:
				if(d > v.size()) cout << "Erro" << endl;
				else{
					v.push_back(v.at(d)->PopFront());
				}	
				break;
			case 7:
				if(d > v.size()) cout << "Erro" << endl;
				else{
					v.push_back(v.at(d)->PopBack());
				}	
				break;
			case 8:
				if(d > v.size()) cout << "Erro" << endl;
				else{
					cout << "Kth: " << v.at(d)->Kth(x) << endl;
				}	
				break;
			case 9:
				if(d > v.size()) cout << "Erro" << endl;
				else{
					cout << "Print: ";
				       	v.at(d)->Print();
				}	
				break;
		}
	}
	return 0;
}
