#include <iostream>
#include "Node.h"

class DEQUE{
	
	private:
		DEQUE* Swap(DEQUE *d);

	public: 
		Node* first; 
		Node* last;
		int length;
		
		DEQUE();
		~DEQUE();
		DEQUE* PushFront(int x);
		DEQUE* PushBack(int x);
		DEQUE* PopFront();
		DEQUE* PopBack();
		int Front();
		int Back();
		int Kth(int k);
		void Print();
};
	
