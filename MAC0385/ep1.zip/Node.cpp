#include <iostream>
#include "Node.h"

Node::Node(int x, Node* p, int d){
	value  = x;
	depth  = d;
	parent = p;
	count = 0;
	
	if(p == NULL){ jump = this;}  	 
	
	else if(p->jump != p and p->depth - p->jump->depth == p->jump->depth - p->jump->jump->depth){
		jump = p->jump->jump;
		jump->count++;
	}
	else{
		jump = p;
		jump->count++;
	}
	return;
}


Node::~Node(){
	parent->count--;
	if(parent->count == 0) delete parent;
	jump->count--;
	if(jump != this and jump->count == 0) delete jump;
}



Node* Node::LA(int k){
	int y = depth - k;
	Node* temp = this;
	while(temp->depth != y){
		if(temp->jump->depth >= y)
			temp = temp->jump;
		else
			temp = temp->parent;
	}
	return temp;		
}

Node* LCA(Node* u, Node* v){
	if(u == NULL or v == NULL)
		return NULL;
	if(u->depth > v->depth){
		Node* temp = u;
		u = v;
		v = temp;
	}
	v = v->LA(v->depth - u->depth);
	if(u == v)
		return u;
	while(u->parent != v->parent){
		if(u->jump != v->jump){
			u = u->jump;
			v = v->jump;
		}
		else{
			u = u->parent;
			v = v->parent;
		}
	}
	return u->parent;
}	
