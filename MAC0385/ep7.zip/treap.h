#include <iostream>
#include <ctime>
#include <cstdlib>

using namespace std;

struct TREAP{
	TREAP *left;
	TREAP *right;
	int data, priority, count;

	TREAP(int dt){
		data = dt;
		priority = rand() % 103;
		left = right = NULL;
		count = 1;
	};
	
	~TREAP(){
		delete left;
		delete right;
	}
};
void recalc(TREAP *node);
TREAP* rotateLeft(TREAP *root);
TREAP* rotateRight(TREAP *root);
TREAP* rotate(TREAP *root);
TREAP* Insert(TREAP *root, int data);
bool Search(TREAP *root, int data);
TREAP* Delete(TREAP* root, int key);
void printTreap(TREAP *root, int space = 0, int height = 5);
int Min(TREAP *root);
void deleta(TREAP *root);
void recalcStats(TREAP *root);
