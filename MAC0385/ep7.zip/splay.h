#include <iostream>
#include <cstdlib>
#include <cstdio>

using namespace std;

struct SPLAY{
	int key;
	int count;
	SPLAY *left;
	SPLAY *right;

	SPLAY(int dt){
		key = dt;
		left = right = NULL;
		count = 1;
	}
	
	~SPLAY(){
		delete left;
		delete right;
	}
};

SPLAY* rotateLeft(SPLAY *root);
SPLAY* rotateRight(SPLAY *root);
SPLAY* splay(SPLAY *root, int key);
SPLAY* insert(SPLAY* root, int key);
SPLAY* remove(SPLAY* root, int key);
SPLAY* search(SPLAY *root, int key);
void printSplay(SPLAY *root, int space = 0, int height = 5);
void recalcStats(SPLAY *root);
int Min(SPLAY *root);
