#include <iostream>
#include "splay.h"

using namespace std;

int main(){
	SPLAY *root = NULL;
	int input, choice;
	while(1)
	{
		cout<<"\nSplay Tree Operations\n";
		cout<<"1. Insert "<<endl;
		cout<<"2. Delete"<<endl;
		cout<<"3. Search"<<endl;
		cout<<"4. Min"<<endl;
		cout<<"5. Print"<<endl;
		cout<<"6. Exit"<<endl;
		cout<<"Enter your choice: ";
		cin>>choice;
		switch(choice)
		{
			case 1:
				cout<<"Enter value to be inserted: ";
				cin>>input;
				root = insert(root, input);
				break;

			case 2:
				cout<<"Enter value to be deleted: ";
				cin>>input;
				root = remove(root, input);
				break;
			case 3:
				cout<<"Enter value to be searched: ";
				cin>>input;
				root = search(root, input);
				break;
			case 6:
				exit(1);
				break;
			case 4:
				cout<<"Min: "<< Min(root) << endl;
				break;
			case 5:
				printSplay(root);
				break;

			default:
				cout<<"\nInvalid type! \n";
		}

	}
	cout<<"\n";
	delete root;
	return 0;
}
