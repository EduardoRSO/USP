#include "treap.h"

void recalcStats(TREAP *node){
	if(node == NULL) return;
	node->count++;
	return;
}

TREAP* rotateLeft(TREAP *root){
	TREAP *two = root->right;
	root->right = two->left;
	two->left = root;

	recalcStats(root);
	recalcStats(two);
	recalcStats(root->right);
	recalcStats(two->left);

	return two;
}

TREAP* rotateRight(TREAP *root){
	TREAP *two = root->left;
	root->left = two->right;
	two->right = root;

	recalcStats(root);
	recalcStats(two);
	recalcStats(root->right);
	recalcStats(two->left);

	return two;
}

TREAP* rotate(TREAP *root){
	if(root->left != NULL and root->priority < root->left->priority) root = rotateRight(root);
	if(root->right != NULL and root->priority < root->right->priority) root = rotateLeft(root);
	return root;
}

TREAP* Insert(TREAP *root, int data){
	if(root == NULL) return new TREAP(data);
	else if(root->data > data) root->left = Insert(root->left,data);
	else root->right = Insert(root->right, data);
	return rotate(root); 

}

bool Search(TREAP *root, int data){
	if(root == NULL) return false;
	else if(root->data > data) return Search(root->left, data);
	else if(root->data < data) return Search(root->right, data);
	else return true;
}

TREAP* Delete(TREAP* root, int key){
	if(root == NULL) return NULL;
	else if(root->data < key) root->right = Delete(root->right,key);
	else if(root->data > key) root->left = Delete(root->left,key);
	else{
		if(root->left == root->right){
			root->right = root->left = NULL;
			delete root;
			return NULL;
		}
		else if(root->left && root->right){
			if(root->right->priority > root->left->priority){
				root = rotateLeft(root);
				root->left = Delete(root->left, key);
			}else{
				root = rotateRight(root);
				root->right = Delete(root->right, key);
				
			}
		}else{
			TREAP *temp;
			if(root->right) temp = root->right;
			else temp = root->left;
			root->right = root->left = NULL;
			delete root;
			return temp;
		
		}
		
	}
	return root;
}

void printTreap(TREAP *root, int space, int height){
	if(root == NULL) return;

	space += height;

	printTreap(root->right, space);
	cout << endl;

	for(int i = height; i < space; i++) cout << ' ';
	cout <<"[ "<<root->data <<", "<<root->priority<< ", "<<root->count<<" ]"<< endl;

	cout << endl;
	printTreap(root->left, space);
}

int Min(TREAP *root){
	if(root == NULL) return -1;
	else if(root->left == NULL) return root->data;
	recalcStats(root);
	return Min(root->left);
}
