#include "splay.h"

void recalcStats(SPLAY *root){
	if(root == NULL) return;
	root->count++;
}

SPLAY* rotateLeft(SPLAY *root){
	SPLAY *one = root->right;
	root->right = one->left;
	one->left = root;
	
	recalcStats(root);
	recalcStats(one);
	recalcStats(root->right);
	recalcStats(one->left);

	return one;
}

SPLAY* rotateRight(SPLAY *root){
	SPLAY *one = root->left;
	root->left = one->right;
	one->right = root;


	recalcStats(root);
	recalcStats(one);
	recalcStats(root->left);
	recalcStats(one->right);

	return one;
}

SPLAY* splay(SPLAY *root, int key){
	if(root == NULL || root->key == key) return root;
	if(root->key > key){
		if(root->left == NULL) 
			return root;
		if(root->left->key > key){
			root->left->left = splay(root->left->left,key);
			root = rotateRight(root);
		}
		else if(root->left->key < key){
			root->left->right = splay(root->left->right, key);

			if(root->left->right != NULL)
				root->left = rotateLeft(root->left);
		}
		
		if(root->left == NULL) return root;
		else return rotateRight(root);
	}
	else{
		if (root->right == NULL) 
			return root;
		if (root->right->key > key){
		    root->right->left = splay(root->right->left, key);

		    if (root->right->left != NULL)
			root->right = rotateRight(root->right);
		}
		else if (root->right->key < key){
		    root->right->right = splay(root->right->right, key);
		    root = rotateLeft(root);
		}

		if(root->right == NULL) return root;
		else return rotateLeft(root);
		
	}
}

SPLAY* insert(SPLAY* root, int key){
	if(root == NULL) return new SPLAY(key);
	root = splay(root, key);
	if(root->key == key) return root;

	SPLAY *node = new SPLAY(key);

	if(root->key > key){
		node->right = root;
		node->left = root->left;
		root->left = NULL;
	}
	else{
		node->left = root;
		node->right = root->right;
		root->right = NULL;
	}
	return node;
}

SPLAY* remove(SPLAY* root, int key){
	SPLAY *temp;
	if(root == NULL) return NULL;
	root = splay(root, key);
	if(key != root->key) return root;
	else{
		if(root->left == NULL){
			temp = root;
			root = root->right;
		}
		else{
			temp = root;
			root = splay(root->left, key);
			root->right = temp->right;
		}
		temp->left = temp->right = NULL;
		delete temp;
		return root;
	}
}

SPLAY* search(SPLAY *root, int key){
	return splay(root,key);
}

void printSplay(SPLAY *root, int space, int height){
	if(root == NULL) return;

	space += height;

	printSplay(root->right, space);
	cout << endl;

	for(int i = height; i < space; i++) cout << ' ';
	cout <<"[ "<<root->key<<", "<<root->count<<" ]"<< endl;

	cout << endl;
	printSplay(root->left, space);
}

int Min(SPLAY *root){
	if(root->left == NULL) return root->key;
	recalcStats(root);
	return Min(root->left);
}
