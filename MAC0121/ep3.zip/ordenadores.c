#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*HEADER*/

typedef struct{
        int c;
        int m;
	int pivo;
} info;

info bubbleSort(int *v, int tamanho);

info insertionSort(int *v, int tamanho);

info mergeSort (int *v, int inicio, int fim);

info quickSort(int *v, int inicio, int fim);

int *retornaOrdenado(int tamanho);

int *retornaParcialmente(int tamanho);

int *retornaAleatorio(int tamanho);

int *retornaInvertido(int tamanho);

int imprimeVetores(int tamanho);

void troca(int *v, int a, int b);

info intercala(int v[], int p, int q, int r);

info separa(int v[], int p, int r);

/*FUNÇÕES*/

info bubbleSort(int *v, int tamanho){
	int i, ok;
	info bubble;
	bubble.c = 0;
	bubble.m = 0;
	ok = 1;
	while(ok){
		bubble.c++;
		ok = 0;
		for(i = 0;i < tamanho-1; i++){
			bubble.c++;
			if(v[i] > v[i+1]){
				bubble.m++;
				troca(v, i, i+1);
				ok = 1;
			}
			bubble.c++;
		}
	}
	return bubble;
}

void troca(int *v, int a, int b){
	int aux;
	aux = v[a];
	v[a] = v[b];
	v[b] = aux;
	return;
}

info insertionSort(int *v, int tamanho){
	int i, j, x;
	info insertion;
	insertion.c = 0;
	insertion.m = 0;
	for(i = 1; i < tamanho; i++){
		insertion.c++;
		x = v[i];
		for(j = i-1; j>=0 && v[j] > x; j--){
			insertion.c++;
			insertion.m++;
			v[j+1] = v[j];
		}
		v[j+1] = x;
		insertion.m++;
	}

	return insertion;
}

info mergeSort (int *v, int inicio, int fim)
{
	info merge;
	info a,b,c;
	a.c =0;
	a.m =0;
	b.c=0;
	b.m=0;
	c.c= 0;
	c.m=0;
	merge.c = 0;
	merge.m = 0;
	if (inicio < fim-1) {                 
		int meio = (inicio + fim)/2;          
		a = mergeSort (v, inicio, meio);        
		b = mergeSort (v, meio, fim);        
		c = intercala (v, inicio, meio, fim);
	}
	merge.c = a.c + b.c + c.c;
	merge.m = a.m + b.m + c.m;	
	return merge;
}

info intercala (int *v, int inicio, int meio, int fim){
	int i, j, *w, k;
	info merge;
	merge.c = 0;
	merge.m = 0;
	w = malloc ((fim-inicio) * sizeof (int));
	for (i = inicio; i < meio; ++i){
	       	merge.c++;
		merge.m++;
		w[i-inicio] = v[i];
	}
	for (j = meio; j < fim; ++j){
		merge.c++;
		merge.m++;
	       	w[fim-inicio+meio-j-1] = v[j];
	}
		i = 0; j = fim-inicio-1;
	for (k = inicio; k < fim; ++k){
		merge.c++;
		if (w[i] <= w[j]){
			v[k] = w[i++];
		}
		else{
		       	v[k] = w[j--];
		}
		merge.c++;
		merge.m++;
	}
		free (w);
		return merge;
}

info quickSort (int *v, int inicio, int fim){
	info quick;
	info a,b,c;
	a.c = 0;
	a.m = 0;
	b.c = 0;
	b.m = 0;
	c.c = 0;
	c.m = 0;
	a.pivo = 0;
	quick.c = 0;
	quick.m = 0;
	if (inicio < fim) {                   
		a = separa (v, inicio, fim);   
		b = quickSort (v, inicio, a.pivo-1);      
		c = quickSort (v, a.pivo+1, fim);
	}
	quick.c = a.c + b.c + c.c;
	quick.m = a.m + b.m + c.m;
	return quick;
}

info separa (int *v, int inicio, int fim) {
	int i, j, pivo;
	info quick;
	quick.c=0;
	quick.m=0;
	quick.pivo=0;
	pivo = v[inicio];
	j = inicio + 1;
	for(i = inicio +1; i < fim; i++){
		quick.c++;
		if(v[i] < pivo){
			troca(v,i,j);
			quick.m++;
			j++;
		}
		quick.c++;
	}
	troca(v,inicio,j-1);
	quick.m++;
	quick.pivo = j-1;
	return quick;

}

/*FUNCOES AUXILIARES*/
int *retornaInvertido(int tamanho){
	int i;
	int *v = malloc(tamanho * sizeof(int));
	
	for(i=0;i<tamanho;i++) v[i] = 0;
	
	for (i = tamanho; i>0;i--){
		v[tamanho - i] = i;
	}
	return v;
}

int *retornaAleatorio(int tamanho){
	int i;
	int *v = malloc(tamanho * sizeof(int));
	
	for(i=0;i<tamanho;i++) v[i] = 0;
	
	for (i = 0; i < tamanho;i++){
		v[i] = (rand() % tamanho);
	}
	return v;
}

int *retornaParcialmente(int tamanho){
	int i;
	int *v = malloc(tamanho * sizeof(int));
	
	for(i=0;i<tamanho;i++) v[i] = 0;
	
	for (i = 0; i < (tamanho/2) ;i++){
		v[i] = i;
		v[tamanho - i - 1] = (rand() % tamanho);
	}
	return v;
}

int *retornaOrdenado(int tamanho){
	int i;
	int *v = malloc(tamanho * sizeof(int));
	
	for(i=0;i<tamanho;i++) v[i] = 0;
	
	for (i = 0; i < tamanho;i++){
		v[i] = i;
	}
	return v;
}

int imprimeVetores(int tamanho){
	int *vet;
	int i;
	vet = retornaOrdenado(tamanho);
	puts("Ordenado");
	for(i=0;i<tamanho;i++) printf("%d ", vet[i]);
	puts("");
	vet = retornaParcialmente(tamanho);
	puts("Parcialmente Ordenado");
	for(i=0;i<tamanho;i++) printf("%d ", vet[i]);
	puts("");
	
	vet = retornaInvertido(tamanho);
	puts("Invertido");
	for(i=0;i<tamanho;i++) printf("%d ", vet[i]);
	puts("");
	
	vet = retornaAleatorio(tamanho);
	puts("Aleatorio");
	for(i=0;i<tamanho;i++) printf("%d ", vet[i]);
	puts("");
	
	return 0;
}

int main(){
	/*x = imprimeVetores(20);*/
	int op, i, tamanho;
	info bubble, insertion, merge, quick;
	scanf("%d",&op);
	switch(op){
		case 1: /*Ordenado*/
			puts("Ordenado");
			printf("Algoritmo, Tamanho, Tipo, Comparacoes, Movimentacoes\n");
			for(i = 1; i <= 128 ;i*=2){
                                int *v1 = retornaOrdenado(i*250);
                                int *v2 = retornaOrdenado(i*250);
                                int *v3 = retornaOrdenado(i*250);
                                int *v4 = retornaOrdenado(i*250);
				bubble = bubbleSort(v1, i*250); 
				insertion = insertionSort(v2, i*250);
				merge = mergeSort(v3, 0, i*250);
				quick = quickSort(v4, 0, i*250);
				printf("Bubble, %d, Ordenado, %d, %d\n", i, bubble.c, bubble.m);
				printf("Insertion, %d, Ordenado, %d\n", i , insertion.c, insertion.m);
				printf("Merge, %d, Ordenado, %d, %d\n", i, merge.c, merge.m);
				printf("Quick, %d, Ordenado, %d, %d\n", i, quick.c, quick.m);
				free(v1);
				free(v2);
				free(v3);
				free(v4);
			}
		break;
		case 2: /*Parcialmente Ordenado*/
			puts("Parcialmente");
			printf("tamanho, bubbleC, bubbleM, insertionC, insetionM, mergeC, mergeM, quickC, quickM\n");
			for(i = 1; i <= 128 ;i*=2){
                                int *v1 = retornaParcialmente(i*250);
                                int *v2 = retornaParcialmente(i*250);
                                int *v3 = retornaParcialmente(i*250);
                                int *v4 = retornaParcialmente(i*250);

				bubble = bubbleSort(v1, i*250); 
				insertion = insertionSort(v2, i*250);
				merge = mergeSort(v3, 0, i*250);
				quick = quickSort(v4, 0, i*250);
				printf("Bubble, %d, Parcialmente, %d, %d\n", i, bubble.c, bubble.m);
				printf("Insertion, %d, Parcialmente, %d\n", i , insertion.c, insertion.m);
				printf("Merge, %d, Parcialmente, %d, %d\n", i, merge.c, merge.m);
				printf("Quick, %d, Parcialmente, %d, %d\n", i, quick.c, quick.m);
				free(v1);
				free(v2);
				free(v3);
				free(v4);
			}
		break;	
		case 3: /*Invertido*/
			puts("Invertido");
			printf("tamanho, bubbleC, bubbleM, insertionC, insetionM, mergeC, mergeM, quickC, quickM\n");
			for(i = 1; i <= 128;i*=2){
                                int *v1 = retornaInvertido(i*250);
                                int *v2 = retornaInvertido(i*250);
                                int *v3 = retornaInvertido(i*250);
                                int *v4 = retornaInvertido(i*250);
				bubble = bubbleSort(v1, i*250); 
				insertion = insertionSort(v2, i*250);
				merge = mergeSort(v3, 0, i*250);
				quick = quickSort(v4, 0, i*250);
				printf("Bubble, %d, Invertido, %d, %d\n", i, bubble.c, bubble.m);
				printf("Insertion, %d, Invertido, %d\n", i , insertion.c, insertion.m);
				printf("Merge, %d, Invertido, %d, %d\n", i, merge.c, merge.m);
				printf("Quick, %d, Invertido, %d, %d\n", i, quick.c, quick.m);
				free(v1);
				free(v2);
				free(v3);
				free(v4);
			}
		break;
		case 4: /*Aleatorio*/
			puts("Aleatorio");
			printf("tamanho, bubbleC, bubbleM, insertionC, insetionM, mergeC, mergeM, quickC, quickM\n");
			for(i = 1; i <= 128;i*=2){
                                int *v1 = retornaAleatorio(i*250);
                                int *v2 = retornaAleatorio(i*250);
                                int *v3 = retornaAleatorio(i*250);
                                int *v4 = retornaAleatorio(i*250);
				bubble = bubbleSort(v1, i*250); 
				insertion = insertionSort(v2, i*250);
				merge = mergeSort(v3, 0, i*250);
				quick = quickSort(v4, 0, i*250);
				printf("Bubble, %d, Aleatorio, %d, %d\n", i, bubble.c, bubble.m);
				printf("Insertion, %d, Aleatorio, %d\n", i , insertion.c, insertion.m);
				printf("Merge, %d, Aleatorio, %d, %d\n", i, merge.c, merge.m);
				printf("Quick, %d, Aleatorio, %d, %d\n", i, quick.c, quick.m);
				free(v1);
				free(v2);
				free(v3);
				free(v4);
			}
		break;
	}
	return 0;
}
