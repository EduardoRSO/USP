#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

/*------------------------------------------------*/
pilha *criaPilha(int tamanho){
	pilha *p = malloc(sizeof(pilha));
	p->topo = 0;
	p->tamanho = tamanho;
	p->v = malloc(tamanho * sizeof(item));
       	if (p->v == NULL){
       		printf("Tamanho inválido");
		return NULL;	
        }
	return p;	
}

item desempilha(pilha *p){
	if(!pilhaVazia(p)){
		p->topo--;
		return p->v[p->topo];
	}
	return;
}

item topoDaPilha(pilha *p){
	if(!pilhaVazia(p)){
		return p->v[p->topo -1];
	}
	return;
}

int pilhaVazia(pilha *p){
	return (p->topo == 0);
}

void empilha(pilha *p, item x){
	p->v[p->topo] = x;
	p->topo++;
	return;
}

void destroiPilha(pilha *p){
	free(p->v);
	free(p);
	return;
}
/*---------------------------------------------------*/
item proximo(item atual, info infoMatriz){
	item novo;
	novo.x = 0;
	novo.y = 0;
	novo.orientacao = 0;
	novo.palavra = atual.palavra; 
	novo.palavra = "";
	novo.restantes = atual.restantes;
	novo.y = (atual.y + 1) % infoMatriz.y;
	novo.x = atual.x;
	if(novo.y == 0) {
		novo.x = (atual.x + 1) % infoMatriz.x;
	}
	return novo;
}

int linhaPreenchida(char **clone, item atual, info infoMatriz){
	int i=0;
	for(i = atual.y; i < infoMatriz.y; i++){
		if(clone[atual.x][i] == '*') break;
		if(clone[atual.x][i] == '!') return 0;
	}

	for(i= atual.y;i >= 0;i--){
		if(clone[atual.x][i] == '*') break;
		if(clone[atual.x][i] == '!') return 0;
	}
	return 1;
	
}

int colunaPreenchida(char **clone, item atual, info infoMatriz){
        int j=0;
        for(j = atual.x; j < infoMatriz.x; j++){
                if(clone[j][atual.y] == '*') break;
		if(clone[j][atual.y] == '!') return 0;
        }

        for(j= atual.x;j >= 0;j--){
                if(clone[j][atual.y] == '*') break;
                if(clone[j][atual.y] == '!') return 0;
        }
        return 1;

}

int verificaEspacoLinha(int **matriz, item atual, info infoMatriz){
        int contador, ok;
        int i=0;
        ok = 0;
        contador = 0;
        while (!ok){
                for (i= atual.y; i < infoMatriz.y; i++){
                        if (matriz[atual.x][i] == -1) break;
                        contador++;
                }
                for (i = atual.y; i >= 0; i--){
                        if (matriz[atual.x][i] == -1) break;
                        contador++;
                }
                ok = 1;
        }
        return contador - 1;
}

int verificaEspacoColuna(int **matriz, item atual, info infoMatriz){
        int contador, ok;
        int i=0;
        ok = 0;
        contador = 0;
        while (!ok){
                for (i= atual.x; i < infoMatriz.x; i++){
                        if (matriz[i][atual.y] == -1) break;
                        contador++;
                }
                for (i = atual.x; i >= 0; i--){
                        if (matriz[i][atual.y] == -1) break;
                        contador++;
                }
                ok = 1;
        }
        return contador-1;
}

char *buscaPalavra(char **palavras, item atual){
	return palavras[atual.restantes-1];
}

int verificaInterfereLinha(char *palavra, item atual, char **clone, info infoMatriz){
	int interfere, min, i;
	min =0;
	interfere = 0;
	for(i= atual.y; i >= 0;i--){
		if (clone[atual.x][i] == '*') break;
		min =i;
	}
	for(i = 0; i < strlen(palavra);i++){
		if (clone[atual.x][i+min] == '!') continue;
		if (!(clone[atual.x][i+min] == palavra[i])){
			interfere = 1;
			break;
		}
	}
	return interfere;

}

int verificaInterfereColuna(char *palavra, item atual, char **clone, info infoMatriz){
	int interfere, min, j;
	min = 0;
	interfere = 0;
	for(j= atual.x; j >= 0;j--){
		if (clone[j][atual.y] == '*') break;
		min = j;
	}
	for(j = 0; j < strlen(palavra);j++){
		if (clone[j+min][atual.y] == '!') continue;
		if (!(clone[j+min][atual.y] == palavra[j])){
			interfere = 1;
			break;
		}
	}
	return interfere;

}

char **removePalavra(char **clone, item atual, info infoMatriz, pilha *decisao){
	int i,j, min;
	char **novo;
	item aux = atual;
	min =0;
	i = 0;
	j=0;
	
	novo = clone;

	for(i = 0; i < infoMatriz.x; i++){
		for(j = 0;j < infoMatriz.y; j++){
			if(novo[i][j] != '*'){
				novo[i][j] = '!';
			}
		}
	}
	i=0;
	while( i < decisao->topo){
		aux = decisao->v[i];
		i++;
		if(aux.orientacao == 0){
			for(j= aux.y; j >=0;j--){
				if(novo[aux.x][j] == '*'){ break;}
				min =j;
			}
			for(j = 0; j < strlen(aux.palavra);j++){
				novo[aux.x][j + min] = aux.palavra[j];
			}
		}else{
			for(j= aux.x; j >=0;j--){
                                if(novo[j][aux.y] == '*'){break;}
				min = j;
			}
			for(j = 0; j < strlen(aux.palavra);j++){
                                novo[j+min][aux.y] = aux.palavra[j];
                        }
		}
		
	}
	
	return novo;
}

void imprimeClone(char **clone, info infoMatriz){
                int i=0,j=0;
                for(i=0;i<infoMatriz.x;i++){
                        for(j=0;j<infoMatriz.y;j++){
				printf("%c ", clone[i][j]);
                        }
                        printf("\n");
                }
}

char **clonaMatriz(int **matriz, info infoMatriz){
        char **clone = malloc( infoMatriz.x * sizeof(char *));
        int i = 0, j = 0;
        for(i = 0;i < infoMatriz.x; i++) clone[i] = malloc( infoMatriz.y *sizeof(char));
        for(i = 0; i < infoMatriz.x; i++){
                for(j = 0; j < infoMatriz.y; j++){
                        if(matriz[i][j] == -1){
                                clone[i][j] = '*';
                        }
                        else{
                                clone[i][j] = '!';
                        }
                }
        }
        return clone;
}

int maiorValor(int linhas, int colunas){
        if (linhas > colunas) return linhas;
        return colunas;
}

void liberaMatriz(int **matriz, info infoMatriz){
        int i=0;
        for(i=0;i<infoMatriz.x;i++){
                free(matriz[i]);
        }
        free(matriz);
        return;
}

void liberaPalavras(char **palavras, info infoMatriz){
        int i =0;
        for(i=0;i<infoMatriz.numPalavras; i++){
                free(palavras[i]);
        }
        free(palavras);
        return;
}

void liberaClone(char **clone, info infoMatriz){
        int i =0;
        for(i=0;i<infoMatriz.x; i++){
                free(clone[i]);
        }
        free(clone);
        return;
}


void imprimeMatriz(int **matriz, info infoMatriz){
        int i=0, j=0;
        for(i = 0;i < infoMatriz.x; i++){
                printf("| ");
                for(j = 0; j < infoMatriz.y; j++){
                                printf("%d | ", matriz[i][j]);
                }
                printf("\n");
        }
        return;
}

int **alocaMatriz(int linhas, int colunas){
	int **matriz = malloc(linhas * sizeof(int *));
	int i = 0;
	for (i = 0; i < linhas; i++){
		matriz[i] = malloc(colunas * sizeof(int));
	}
	return (matriz);

}

void **recebeValores(int **matriz, int linha, int coluna){
	int i = 0;
	int j = 0;
	int valor = 0;
	for(i=0;i<linha;i++){
		for(j=0;j<coluna;j++){
			scanf("%i",&valor);
			matriz[i][j] = valor;
		}
	}
}

char **recebePalavras(int numPalavras, int max){
	char **palavras = malloc(numPalavras * sizeof(char *));
	int i = 0;
	for (i=0; i< numPalavras; i++){
		palavras[i] = malloc((max+1) * sizeof(char));
	}
	for (i = 0; i < numPalavras; i++){
			scanf("%s", palavras[i]);
			palavras[i][max] = '\0';
	}
	
	return palavras;
}

void inserePalavraClone(char **clone, item atual){
	int i,min;
	i=0;
	min =0;
	if (atual.orientacao == 0){
		for(i = atual.y; i>=0;i--){
			if (clone[atual.x][i] == '*') break;
			min = i;
		}
		for(i = 0; i < strlen(atual.palavra);i++){
                                clone[atual.x][i+min] = atual.palavra[i];
                        }
	}else{
		for(i = atual.x; i>=0;i--){
                        if (clone[i][atual.y] == '*'){break;}
			min = i;
                }
                for(i = 0; i < strlen(atual.palavra);i++){
                          clone[i+min][atual.y] = atual.palavra[i];
                }
	}
	return;
}
                            
int verificaExistencia(char *palavra, item atual, char **clone, info infoMatriz, int o, int espaco, char **palavras){
	int i, min, letras;
	char *aux = palavra;
	letras =0;
	min = 0;
	i=0;
	if(o == 0 && espaco >= 2){
		if (atual.x == (infoMatriz.x-1) || clone[atual.x+1][atual.y] == '*'){
			for(i = atual.x; i>=0;i--){
                                if (clone[i][atual.y] == '*') break;
                                min =i;
                        }
                        for(i=0; i < atual.x;i++){
                               if(clone[min+i][atual.y] == '*') break;
                               aux[i] = clone[i+min][atual.y];
                               letras++;
			}
                        aux[letras-1] = palavra[letras-1];
			aux[letras] = '\0';
                        return buscaBinaria(palavras, aux, infoMatriz);
		}
	}
	if(o == 1 && espaco >= 2){
			if (atual.y == (infoMatriz.y-1) || clone[atual.x][atual.y+1] == '*'){
				for(i = atual.y; i>=0;i--){
                                	if (clone[atual.x][i] == '*') break;
                                	min = i;
                        	}
                        	for(i=min; i < infoMatriz.y;i++){
                                	if(clone[atual.x][i] == '*') break;
                                	aux[i-min] = clone[atual.x][i]; 
                                	letras++;
                        	}
                        aux[letras] = palavra[0];
                        return buscaBinaria(palavras, aux, infoMatriz);

                }
	

	}
	return 1;
}

int buscaBinaria(char **palavras, char *palavra, info infoMatriz){
	int i=0;
	for(i=0;i< infoMatriz.numPalavras;i++){
		if(strcmp(palavras[i], palavra) == 0){ 
			return 1;
		}
	}
	return 0;
}

void trocaVolta(char **palavras, item atual, info infoMatriz, int palavrasRestantes){
	char *aux = atual.palavra;
	aux = palavras[atual.restantes-1];
	palavras[atual.restantes-1] = atual.palavra;
	palavras[palavrasRestantes-1] = aux;	
}

void trocaEmpilha(char **palavras, item atual, info infoMatriz, int palavrasRestantes){
        palavras[atual.restantes-1] = palavras[palavrasRestantes-1];
        palavras[palavrasRestantes-1] = atual.palavra;
}


