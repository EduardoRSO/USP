#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "funcoes.h"

void backtrack(int **matriz, int numPalavras, char **palavras, int matx, int maty){
	int palavrasRestantes;
	int existeOP, espaco, barreira;
	item atual;
	info infoMatriz;
	char ** clone;
        char *palavra;
	pilha *decisao;
	infoMatriz.x = matx;
        infoMatriz.y = maty;
	infoMatriz.numPalavras = numPalavras;
	decisao = criaPilha(infoMatriz.numPalavras+1);
	clone = clonaMatriz(matriz, infoMatriz);
	palavra = malloc((maiorValor(infoMatriz.x, infoMatriz.y)+1) * sizeof(char));
	espaco = 0;
	atual.x = 0;
	atual.y = 0;
	atual.palavra = palavra;
	atual.orientacao = 0;
	atual.palavra = "oi";
	palavrasRestantes = infoMatriz.numPalavras;
	atual.restantes = palavrasRestantes;
	while(!(((atual.x == infoMatriz.x-1) && (atual.y == infoMatriz.y-1)))){
		existeOP = 0;
		barreira = 0;
		while(!(existeOP) && atual.restantes > 0){
			/* Se for barreira, pula pra proxima posição*/
			if(matriz[atual.x][atual.y] == -1 ){
				atual = proximo(atual, infoMatriz);
				if((atual.x == infoMatriz.x-1) && (atual.y == infoMatriz.y-1)){
                                        existeOP = 1;
                                        barreira = 1;
                                       	break;
                                }

				continue;
			}	
			/*Se a coluna e linha estiverem preenchidas, pula pra proxima*/
			if(colunaPreenchida(clone, atual, infoMatriz) && linhaPreenchida(clone,atual,infoMatriz)){
                                atual = proximo(atual, infoMatriz);
                                if((atual.x == infoMatriz.x-1) && (atual.y == infoMatriz.y-1)){ 
					existeOP = 1;
					barreira = 1;
					break;
					}
				continue;
			}
			/*Se a linha e coluna tiverem espaço 1*/
			if(verificaEspacoLinha(matriz, atual, infoMatriz) < 2 && verificaEspacoColuna(matriz,atual,infoMatriz) < 2){
				break;
			}	
			/*verifica se a linha está preenchida*/
			if(!(linhaPreenchida(clone, atual, infoMatriz))){
					espaco = verificaEspacoLinha(matriz, atual, infoMatriz);
					/*Se o espaço na linha é maior que 2*/
					if(espaco >=2){
						/*Enquanto restarem palavras disponíveis*/
						while(atual.restantes > 0){
							palavra = buscaPalavra(palavras, atual);
								/*Busca uma palavra e verifica se o tamanho dela é compatível e verifica se ela interfere nos demais caracteres da linha*/
								if((strlen(palavra) == espaco) && !(verificaInterfereLinha(palavra, atual, clone, infoMatriz))){
									/*Verifica se a palavra formada na coluna, ao inserir a palavra na linha existe*/
									if(verificaExistencia(palavra, atual, clone, infoMatriz, 1, espaco, palavras)){
										existeOP = 1;
										atual.orientacao = 0;
										atual.palavra = palavra;
									break;
									}
									/*Se a palavra formada na coluna não existir, pula pra proxima*/
									atual.restantes--;
								}
								/*Se a palavra não tiver o tamanho necessário ou interferir, pula pra proxima*/
								else{
									atual.restantes--;
								}
						}
					}

			}
			/*Se a coluna não estiver preenchida e não houver opção na linha*/
			if(!(colunaPreenchida(clone, atual, infoMatriz)) && !(existeOP)){
					espaco = verificaEspacoColuna(matriz, atual, infoMatriz);
					/*Se o espaço na coluna é maior que 2*/
					if(espaco>=2){
						/*Enquanto restarem palavras disponíveis*/
						while(atual.restantes > 0){
							palavra = buscaPalavra(palavras, atual);
							/*Busca uma palavra, verifica se o tamanho dela é compativel e verifica se ela interfere nos demais caracteres da coluna*/
							if((strlen(palavra) == espaco) &&!(verificaInterfereColuna(palavra, atual, clone, infoMatriz))){
								/*Verifica se a palavra formada na linha, ao inserir a palavra na coluna, existe*/
								if(verificaExistencia(palavra, atual, clone, infoMatriz, 0, espaco, palavras)){
									existeOP = 1;
									atual.orientacao = 1;
									atual.palavra = palavra;
								break;
								}
								/*Se a palavra formada na linha não existir, pula pra proxima*/
								atual.restantes--;
							}
							/*Se a palavra não tiver o tamanho necessário ou interferir, pula pra próxima*/
							else{
								atual.restantes--;
							}
						}
					}
			}	
		}
		if(existeOP){
			if(!barreira){
			trocaEmpilha(palavras, atual, infoMatriz, palavrasRestantes);
			palavrasRestantes--;
			empilha(decisao, atual);
			inserePalavraClone(clone, atual);
			
			atual = proximo(atual, infoMatriz);
			atual.restantes = palavrasRestantes;			
			}
		}
		else{
			if(pilhaVazia(decisao)){
				printf("Nao ha solucao\n");
				destroiPilha(decisao);
				liberaMatriz(matriz, infoMatriz);
				liberaClone(clone, infoMatriz);
				liberaPalavras(palavras, infoMatriz);
				return;
			}
			atual = desempilha(decisao);
			palavrasRestantes++;
                        trocaVolta(palavras, atual, infoMatriz, palavrasRestantes);
			atual.restantes--;
			clone = removePalavra(clone, atual, infoMatriz, decisao);
		}
	}
	imprimeClone(clone, infoMatriz);
	destroiPilha(decisao);
	liberaMatriz(matriz, infoMatriz);
	liberaClone(clone, infoMatriz);
	liberaPalavras(palavras, infoMatriz);
	return;
}


int main(){
	int linhas = 1;
	int colunas = 1;
	int **matriz = 0;
	char **palavras;
	int numPalavras = 0;
	int instancias=1; 
	scanf("%d %d",&linhas, &colunas);
	while (linhas != 0 && colunas != 0){
		printf("Instancia %d\n", instancias);
		matriz = alocaMatriz(linhas,colunas);
		recebeValores(matriz, linhas, colunas);
		scanf("%d", &numPalavras);
		palavras = recebePalavras(numPalavras, maiorValor(linhas,colunas));
		backtrack(matriz, numPalavras, palavras, linhas, colunas);
		puts("");
		scanf("%d %d", &linhas, &colunas);
		instancias++;
	}
	return 0;
}

