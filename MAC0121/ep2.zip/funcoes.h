#include <stdio.h>
typedef struct{
	int x;
	int y;
	int orientacao;
	int restantes;
	char *palavra;
} item;

typedef struct{
	int x;
	int y;
	int numPalavras;
} info;

typedef struct{
	int topo;
	int tamanho;
	item *v;
}pilha;

pilha *criaPilha(int tamanho);
item desempilha(pilha *p);
item topoDaPilha(pilha *p);
void destroiPilha(pilha *p);
void empilha(pilha *pi, item x);
int pilhaVazia(pilha *p);

/*A função retorna a proxima posição da matriz a ser verificada*/
item proximo(item atual, info infoMatriz);
/*A função verifica se o espaco todo ja está preenchido*/
int linhaPreenchida(char **clone, item atual, info infoMatriz);
/*A função verifica se o espaco todo ja está preenchido*/
int colunaPreenchida(char **clone, item atual, info infoMatriz);
/*A função retorna o espaco disponível naquela posicao*/
int verificaEspacoLinha(int **matriz, item atual, info infoMatriz);
/*A função retorna o espaco disponível naquela posicao*/
int verificaEspacoColuna(int **matriz, item atual, info infoMatriz);
/*A função busca uma palavra na matriz de palavras baseado no indice dado pelo item atual*/
char *buscaPalavra(char **palavras, item atual);
/*A função verifica se uma dada palavra interfere nas demais palavras na matriz de char*/
int verificaInterfereLinha(char *palavra, item atual, char **clone, info infoMatriz);
/*A função verifica se uma dada palavra interfere nas demais palavras na matriz de char*/
int verificaInterfereColuna(char *palavra, item atual, char **clone, info infoMatriz);
/*A função remove a palavra da matriz de char*/
char **removePalavra(char **clone, item atual, info infoMatriz, pilha *decisao);
/*A função imprime a matriz de char*/
void imprimeClone(char **clone, info infoMatriz);
/*A função aloca a memoria necessaria e retorna uma matriz de char*/
char **clonaMatriz(int **matriz, info infoMatriz);
/*A função retorna o maior valor entre os parametros*/
int maiorValor(int linhas, int colunas);
/*A função libera a memoria alocada*/
void liberaMatriz(int **matriz, info infoMatriz);
/*A função libera a memoria alocada*/
void liberaPalavras(char **palavras, info infoMatriz);
/*A função libera a memoria alocada*/
void liberaClone(char **clone, info infoMatriz);
/*A função imprime a matriz de inteiros*/
void imprimeMatriz(int **matriz, info infoMatriz);
/*A função aloca uma matriz de inteiros*/
int **alocaMatriz(int linhas, int colunas);
/*A função recebe os valores da matriz de inteiros*/
void **recebeValores(int **matriz, int linhas, int colunas);
/*A função recebe as palavras e retorna a matriz de palavras*/
char **recebePalavras(int numPalavras, int max);
/*A função insere na matriz clone a palavra*/
void inserePalavraClone(char **clone, item atual);
/*A função retorna true ou false ao verificar, de acordo com a orientacao, se a palavra formada na linha ou coluna existe*/
int verificaExistencia(char *palavra, item atual, char **clone, info infoMatriz, int o, int espaco ,char **palavras);
/*A função retorna true ou false se a palavra existir na matriz de palavras*/
int buscaBinaria(char **palavras, char *palavra, info infoMatriz);
/*A função reordena a matriz de palavras, colocando a palavra escolhida na última posição entre as palavras que estavam disponíveis*/
void trocaEmpilha(char **palavras, item atual, info infoMatriz, int palavrasRestantes);
/*A função reordena a matriz de palavras, retornando a palavra ao indice no qual estava*/
void trocaVolta(char **palavras, item atual, info infoMatriz, int palavrasRestantes);
