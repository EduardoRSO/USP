#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAMANHO 8191 
#define LENGTH 30

typedef struct {
	int linha;
	int cont;
}item;

struct cel{
	item info;
	struct cel *prox;
};

typedef struct cel celula;

typedef struct{
	char *palavra;
	celula *inicio;
} placa;

celula * insereNoFimRec (celula * inicio, item x) {
  if (inicio == NULL) {
    inicio = malloc (sizeof(celula));
    inicio->info = x;
    inicio->prox = NULL;
  }
  else{ 
	if(inicio->info.linha == x.linha) inicio->info.cont++;
	else inicio->prox = insereNoFimRec (inicio->prox, x);
  }
  return inicio;
}

void imprimeListaIterativo (celula * inicio) {
	celula * p;
	for (p = inicio; p != NULL; p = p -> prox)
		if(p->info.cont == 1) printf("%d ", p->info.linha); 
		else  printf("%d(%d) ", p->info.linha, p->info.cont); 
	printf("\n");
} 

placa **criaTabela(){
	placa **tHashing = malloc(TAMANHO * sizeof(placa *));
	int i;
	for(i=0; i< TAMANHO;i++){
		tHashing[i] = malloc(sizeof(placa));
		tHashing[i]->palavra = malloc(LENGTH * sizeof(char));
		memset(tHashing[i]->palavra, '\0', LENGTH);
		tHashing[i]->inicio = NULL;
	}
	return tHashing;
}

void adicionaEntrada(placa **tHashing, int index, item x, char *entrada){
	char *novo = malloc(LENGTH*sizeof(char));
	memset(novo,'\0',LENGTH);
	strcpy(novo,entrada);
	tHashing[index]->palavra = novo;
	tHashing[index]->inicio = insereNoFimRec(tHashing[index]->inicio, x);
}

void imprimetHashing(placa **tHashing){
	int i=0;
	for(i = 0; i< TAMANHO; i++)
		if(tHashing[i]->inicio != NULL){
			printf("%s: ",tHashing[i]->palavra);
			imprimeListaIterativo(tHashing[i]->inicio);
		}
}

void liberaLista(celula *inicio)
{
        if (inicio == NULL) return;
        else{
		liberaLista(inicio->prox);
        	free(inicio);
        }
}

void liberaTabela (placa ** tHashing) {
  int i;
  for (i = 0; i < TAMANHO; i++) {
    free (tHashing[i]->palavra);
    liberaLista (tHashing[i]->inicio);
    free (tHashing[i]);
  }
  free(tHashing);
}

char proximoCaractere(FILE *arq){
	char letra = getc(arq);
	if(((int)letra >= 65  && (int)letra <= 90) || ((int)letra >= 97 && (int)letra <= 122) || letra == EOF || letra == '\n') return letra;
	else return '!';
}

int ehVogal(char p){
	char letra = tolower(p);
	if (letra == 'a') return 3; 
	else if (letra == 'e') return 7;
	else if (letra == 'i') return 11;
	else if (letra == 'o') return 13;
	else if (letra == 'u') return 19;
	else return 1;
}

int hashing(char *p){
	int M = TAMANHO;
	int i, hash = 3;
	for (i = 0; i < strlen(p); i++)
		hash = (hash*53 + (int)p[i]* ehVogal(p[i])) % M;
	return hash;
}

int comparaString(char *p1, char *p2){
	int i = 0, res = 0;
	char a[LENGTH+1], b[LENGTH+1];
	strcpy(a, p1);
	strcpy(b, p2);
	for(i = 0; i <strlen(a);i++){
		a[i] = tolower(a[i]);
	}
	for(i = 0; i <strlen(b);i++){
		b[i] = tolower(b[i]);
	}
	res = strcmp(a,b);
	if (res == 0) return 1;
	return res;
}

placa **ordenatHashing(placa **t){	
	int i, j, k;
	char vazio[LENGTH];
	placa *aux = malloc(sizeof(placa));
	memset(vazio,'\0',LENGTH);
	for(i= TAMANHO -1; i>=0; i--){
		k = i;
		for(j=0; j<i ;j++){
			if(strcmp(t[k]->palavra, vazio) != 0 && strcmp(t[j]->palavra, vazio) !=0 && comparaString(t[j]->palavra, t[k]->palavra) > 0){
				k = j;
			}
		}
		
		if(i != k && comparaString(t[k]->palavra, t[i]->palavra) != 0){
			aux->palavra = t[i]->palavra;
			aux->inicio = t[i]->inicio;
			t[i]->palavra = t[k]->palavra; 
			t[i]->inicio = t[k]->inicio;  
			t[k]->palavra = aux->palavra;
			t[k]->inicio = aux->inicio;
		}
	}
	
	return t;
}

int main(){
 	char nomeArq[LENGTH];
	char palavra[LENGTH];
	char vazio[LENGTH];
	char letra;
	int indice, linha, index;
	FILE *arq;
	item info;
	placa **tHashing = criaTabela();
	placa **ordenada;
	memset(nomeArq,'\0',LENGTH);
	memset(vazio,'\0',LENGTH);
	indice = 0;
	linha = 1;
	scanf("%s", nomeArq);
	arq = fopen(nomeArq, "r");
	letra = proximoCaractere(arq);
	while (letra != EOF){
		if(letra != '!' && letra != EOF && letra != '\n'){
			palavra[indice] = letra;
			indice++;
		}else{
			if(strcmp(palavra, vazio) != 0){
				index = hashing(palavra);
				info.linha = linha;
				info.cont = 1;
				adicionaEntrada(tHashing, index, info, palavra);
				memset(palavra,'\0',LENGTH);
			}
			if (letra == '\n') linha++;
			indice = 0;
		}
		letra = proximoCaractere(arq);
	}
	ordenada = ordenatHashing(tHashing);
	imprimetHashing(ordenada);
	liberaTabela(ordenada);
	return 0;
}
