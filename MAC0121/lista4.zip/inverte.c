#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>

typedef struct cel {
	int x;
	struct cel * prox;
} celula; 


celula *inverte(celula*inicio){
	celula *aux1, *aux2, *aux3;
	if(inicio == NULL || inicio->prox == NULL) return inicio;
	aux1 = inicio;
	aux2 = inverte(inicio->prox);
	aux1->prox = NULL;
	aux3 = aux2;
	while(aux2->prox != NULL) aux2 = aux2->prox;
	aux2->prox = aux1;
	inicio = aux3;
}

celula *insereNoFimRec(celula *inicio, int val){
	if(inicio == NULL){
		inicio = malloc(sizeof(celula));
		inicio->x = val;
		inicio->prox = NULL;
	}else inicio->prox = insereNoFimRec(inicio->prox, val);
	return inicio;
}

celula *criaLista(int celulas){
	int i = 0;
	celula *nova = malloc(sizeof(celula));
	for(i=1;i<celulas; i++){
		nova = insereNoFimRec(nova, i);
	}
	return nova;
}

void imprimeRec(celula *inicio){
	if (inicio != NULL){
		printf("%d ->", inicio->x);
		return imprimeRec(inicio->prox);
	}
	printf("NULL\n");	
}

void liberaLista(celula *inicio)
{
	if (inicio == NULL) return;
	else{liberaLista(inicio->prox);
	free(inicio);
	}
}
void testa(int n){
	celula *lista = malloc(sizeof(celula));
	lista = criaLista(n); 
	puts("Sem Inverte");
	printf("IMPRIME: "); imprimeRec(lista);
	puts("");
	puts("");
	celula *atsil = malloc(sizeof(celula));
	atsil = inverte(lista);
	puts("Com inverte");
	printf("IMPRIME: "); imprimeRec(atsil);
	liberaLista(lista);
	return;
}

int main(){
	puts("Insira o número de elementos que a lista deve ter:");
	int valor = 0;
	scanf("%d", &valor);
 	testa(valor);
	return 0;
}
