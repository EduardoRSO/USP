#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
	int i, j, l, c, x, contador, ant_i, ant_j;
	int **mat;
	scanf("%d %d",&l, &c);
	mat = malloc( l * sizeof(int *));
	for(i=0;i<l;i++) mat[i] = malloc( c * sizeof(int));
	
	for(i=0;i<l;i++)
		for(j=0;j<c;j++)
			mat[i][j] = 0;
	
	for(i=0;i<l;i++){
		for(j=0;j<c;j++){
			scanf("%d", &x);
			mat[i][j] = x;
		}
	}
	scanf("%d",&x);
	i = l-1;
	j = 0;
	ant_i = 0;
	ant_j = 0;
	contador =0;
	while(contador<2*(l+c)){
		ant_j = j;
		ant_i = i;
		if(j < c-1 && mat[i][j] < x){
			j++;
			/*printf("mat[%d][%d] = %d\n",i,j, mat[i][j]);*/
		}
		if(i > 0 && mat[i][j] > x){
			i--;
			/*printf("mat[%d][%d] = %d\n",i,j, mat[i][j]);*/
		}
		contador = contador + 2;
		if((ant_i == i) && (ant_j == j)) break;
	}
	int valor = mat[i][j];
	if(x == valor){
	       	printf("X = %d e mat[%d][%d] = %d\n",x,i,j, mat[i][j]);
	}
	else printf("X = %d não esta na matriz\n",x);
	/*printf("contador = %d\n",contador);*/
	return 0;
}
